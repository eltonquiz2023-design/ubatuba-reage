---
name: render-slides
description: Usa Puppeteer para capturar cada slide do HTML como PNG 1080x1350px
---

# Task: Renderizar Slides como PNG

## Input

- Caminho do `slides.html` gerado na task anterior
- Pasta de destino para os PNGs: mesma pasta do `slides.html`

## Process

**1. Crie o script de renderização**

Salve o script em `squads/ubatuba-reage/output/{run_id}/v{n}/slides/render.js`:

```javascript
const puppeteer = require('puppeteer');
const path = require('path');

const htmlPath = path.resolve(__dirname, 'slides.html');
const fileUrl = 'file:///' + htmlPath.replace(/\\/g, '/');

(async () => {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--font-render-hinting=none']
  });
  const page = await browser.newPage();

  // Aguarda fonts carregarem
  await page.goto(fileUrl, { waitUntil: 'networkidle0', timeout: 30000 });
  await page.waitForTimeout(1000); // aguarda Google Fonts

  // Conta slides
  const slideCount = await page.evaluate(() =>
    document.querySelectorAll('.slide').length
  );

  console.log(`Renderizando ${slideCount} slides...`);

  for (let i = 1; i <= slideCount; i++) {
    const slideId = `slide-${i}`;
    const el = await page.$(`#${slideId}`);
    if (!el) {
      console.warn(`Slide #${slideId} não encontrado, pulando.`);
      continue;
    }

    const num = String(i).padStart(2, '0');
    const outPath = path.join(__dirname, `slide-${num}.png`);

    await el.screenshot({
      path: outPath,
      type: 'png',
      clip: { x: 0, y: 0, width: 1080, height: 1350 }
    });

    console.log(`✓ slide-${num}.png salvo`);
  }

  await browser.close();
  console.log('Renderização concluída!');
})();
```

**2. Execute o script**

```bash
node squads/ubatuba-reage/output/{run_id}/v{n}/slides/render.js
```

**3. Verifique os arquivos gerados**

```bash
ls -la squads/ubatuba-reage/output/{run_id}/v{n}/slides/*.png
```

Confirme que:
- Existe um PNG para cada slide (slide-01.png a slide-09.png)
- Cada arquivo tem tamanho > 50KB (slides em branco têm < 10KB — erro)
- Nenhum arquivo tem 0 bytes

## Output Format

Ao finalizar, reporte:

```
✅ Slides renderizados com sucesso

📁 Pasta: squads/ubatuba-reage/output/{run_id}/v{n}/slides/
📊 Total: 9 slides

slide-01.png  — CHOQUE (capa escura)       [XXX KB]
slide-02.png  — FATO (laranja)             [XXX KB]
slide-03.png  — CONTEXTO (escuro)          [XXX KB]
slide-04.png  — PROVA (laranja)            [XXX KB]
slide-05.png  — COMPARAÇÃO (escuro)        [XXX KB]
slide-06.png  — REVELAÇÃO (navy)           [XXX KB]
slide-07.png  — ACCOUNTABILITY (claro)     [XXX KB]
slide-08.png  — CTA (escuro)               [XXX KB]
slide-09.png  — CRÉDITOS (escuro)          [XXX KB]
```

## Veto Conditions

- **VETO** se qualquer PNG tiver menos de 30KB — indica slide em branco ou erro de renderização
- **VETO** se o número de PNGs for diferente do número de slides no HTML

## Quality Criteria

- Todos os PNGs são gerados sem erro de Puppeteer
- Os arquivos têm tamanho consistente (nenhum outlier abaixo de 30KB)
- O script conclui sem exceções não tratadas
