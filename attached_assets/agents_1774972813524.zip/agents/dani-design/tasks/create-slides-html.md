---
name: create-slides-html
description: Gera arquivo HTML/CSS com os 9 slides do carrossel em formato 1080x1350px seguindo o design system oficial @ubatubareage
---

# Task: Criar Slides HTML

## ANTES DE COMEÇAR — Leia as referências obrigatórias

```bash
cat squads/ubatuba-reage/pipeline/data/design-system.md
```

E opcionalmente a referência HTML com exemplos implementados:
```bash
cat squads/ubatuba-reage/pipeline/data/design-system-reference.html
```

Estas referências contêm o design system completo: cores, tipografia, layouts de cada slide, regras de alternância cromática e briefings de imagem.

## Input

Leia o arquivo de briefing do carrossel:
- `squads/ubatuba-reage/output/{run_id}/v{n}/instagram-feed-draft.md`

Se o caminho exato não for passado como contexto, use o arquivo mais recente em:
```bash
ls -t squads/ubatuba-reage/output/*/v*/instagram-feed-draft.md | head -1
```

## Process

**1. Leia o briefing completo**

Extraia para cada um dos 9 slides:
- Função narrativa (CHOQUE / FATO / CONTEXTO / PROVA / COMPARAÇÃO / REVELAÇÃO / ACCOUNTABILITY / CTA / CREDIBILIDADE)
- Headline (campo `HEADLINE:`)
- Corpo regular (campo `CORPO REGULAR:`) — peso 500
- Corpo bold (campo `CORPO BOLD:`) — peso 800
- Imagem (campo `IMAGEM:`) — descrição da composição para placeholder

**2. Mapeie cada slide ao seu tipo visual**

Seguindo a alternância cromática obrigatória do design system:

| Slide | Função       | Fundo        | Classe CSS          |
|-------|--------------|--------------|---------------------|
| 1     | CAPA         | `--dark-bg`  | `slide--capa`       |
| 2     | CONTEXTO     | `--orange`   | `slide--contexto`   |
| 3     | DESENVOLVIMENTO | `--dark-bg` | `slide--dev`      |
| 4     | PROVAS       | `--orange`   | `slide--provas`     |
| 5     | APROFUNDAMENTO | `--dark-bg` | `slide--aprofund`  |
| 6     | REVELAÇÃO    | `--dark-navy`| `slide--revelacao`  |
| 7     | ACCOUNTABILITY | `--light-bg` | `slide--account`  |
| 8     | CTA          | `--dark-bg`  | `slide--cta`        |
| 9     | CRÉDITOS     | `--dark-bg`  | `slide--creditos`   |

**3. Gere o HTML completo**

Use esta estrutura base CSS para o documento:

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=1080">
  <title>Carrossel @ubatubareage</title>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --orange: #FF4D00;
      --orange-dark: #E64400;
      --dark-bg: #0A0E14;
      --dark-navy: #0C1220;
      --light-bg: #F0F0F0;
      --white: #FFFFFF;
      --black: #000000;
      --text-dark: #1A1A2E;
      --arrow-orange: #FF6B1A;
    }

    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Plus Jakarta Sans', sans-serif; background: #333; padding: 20px; }

    .slide {
      width: 1080px;
      height: 1350px;
      position: relative;
      overflow: hidden;
      font-family: 'Plus Jakarta Sans', sans-serif;
      margin-bottom: 30px;
    }

    /* Header bar — presente em TODOS os slides */
    .slide-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 28px 40px;
      font-size: 18px;
      font-weight: 700;
      letter-spacing: 2px;
      text-transform: uppercase;
      position: absolute;
      top: 0; left: 0; right: 0;
      z-index: 10;
    }
    .slide-header--dark { color: rgba(255,255,255,0.4); }
    .slide-header--light { color: rgba(0,0,0,0.4); }

    /* Círculo seta laranja */
    .arrow {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: var(--arrow-orange);
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .arrow::after {
      content: '→';
      color: var(--white);
      font-size: 24px;
      font-weight: 700;
    }

    /* Imagem placeholder */
    .img-placeholder {
      background: rgba(255,255,255,0.1);
      display: flex;
      align-items: center;
      justify-content: center;
      color: rgba(255,255,255,0.3);
      font-size: 18px;
      font-weight: 500;
      text-align: center;
      padding: 20px;
    }
    .img-placeholder--light {
      background: rgba(0,0,0,0.08);
      color: rgba(0,0,0,0.3);
    }

    /* ─── SLIDE 1 — CAPA ─── */
    .slide--capa {
      background: var(--dark-bg);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-end;
      padding-bottom: 80px;
    }
    .slide--capa .bg-image {
      position: absolute;
      inset: 0;
      width: 100%;
      height: 100%;
      object-fit: cover;
      z-index: 0;
    }
    .slide--capa .gradient-overlay {
      position: absolute;
      inset: 0;
      background: linear-gradient(to top, rgba(10,14,20,0.95) 40%, rgba(10,14,20,0.4) 100%);
      z-index: 1;
    }
    .slide--capa .capa-content {
      position: relative;
      z-index: 2;
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
      padding: 0 60px;
      gap: 28px;
    }
    .slide--capa .logo-badge {
      width: 90px;
      height: 90px;
      border-radius: 50%;
      background: var(--orange);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 13px;
      font-weight: 800;
      color: var(--white);
      text-align: center;
      letter-spacing: 1px;
      text-transform: uppercase;
      line-height: 1.2;
    }
    .slide--capa h1 {
      font-size: 88px;
      font-weight: 800;
      color: var(--white);
      text-transform: uppercase;
      letter-spacing: -2px;
      line-height: 0.95;
      max-width: 960px;
    }
    .slide--capa .subtitle {
      font-size: 22px;
      font-weight: 700;
      color: rgba(255,255,255,0.7);
      text-transform: uppercase;
      max-width: 900px;
      line-height: 1.3;
    }

    /* ─── SLIDE 2 — CONTEXTO (laranja) ─── */
    .slide--contexto {
      background: var(--orange);
      display: flex;
      flex-direction: column;
    }
    .slide--contexto .contexto-headline {
      font-size: 82px;
      font-weight: 800;
      color: var(--text-dark);
      text-transform: uppercase;
      letter-spacing: -2px;
      line-height: 0.95;
      padding: 100px 50px 40px;
    }
    .slide--contexto .contexto-image {
      margin: 0 40px;
      height: 520px;
      border-radius: 4px;
      overflow: hidden;
    }
    .slide--contexto .contexto-body {
      font-size: 38px;
      font-weight: 800;
      color: var(--white);
      line-height: 1.22;
      padding: 40px 50px;
      flex: 1;
    }

    /* ─── SLIDE 3 — DESENVOLVIMENTO (escuro, texto dual) ─── */
    .slide--dev {
      background: var(--dark-bg);
      display: flex;
      flex-direction: column;
    }
    .slide--dev .dev-image {
      margin-top: 70px;
      width: 100%;
      height: 580px;
      overflow: hidden;
      flex-shrink: 0;
    }
    .slide--dev .dev-image img,
    .slide--dev .dev-image .img-placeholder {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .slide--dev .arrow-wrap {
      padding: 30px 0 20px 50px;
    }
    .slide--dev .body-regular {
      font-size: 36px;
      font-weight: 500;
      color: var(--white);
      line-height: 1.35;
      padding: 0 50px;
    }
    .slide--dev .body-bold {
      font-size: 38px;
      font-weight: 800;
      color: var(--white);
      line-height: 1.22;
      padding: 20px 50px 50px;
    }

    /* ─── SLIDE 4 — PROVAS (laranja) ─── */
    .slide--provas {
      background: var(--orange);
      display: flex;
      flex-direction: column;
    }
    .slide--provas .provas-headline {
      font-size: 68px;
      font-weight: 800;
      color: var(--orange-dark);
      text-transform: uppercase;
      letter-spacing: -2px;
      line-height: 0.95;
      padding: 90px 50px 30px;
    }
    .slide--provas .provas-image {
      margin: 0 40px;
      height: 500px;
      border-radius: 4px;
      overflow: hidden;
    }
    .slide--provas .provas-body {
      font-size: 34px;
      font-weight: 500;
      color: var(--black);
      line-height: 1.35;
      padding: 40px 50px;
      flex: 1;
    }

    /* ─── SLIDE 5 — APROFUNDAMENTO (escuro, texto dual) ─── */
    .slide--aprofund {
      background: var(--dark-bg);
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    .slide--aprofund .body-regular {
      font-size: 36px;
      font-weight: 500;
      color: var(--white);
      line-height: 1.35;
      padding: 90px 50px 0;
    }
    .slide--aprofund .arrow-wrap {
      padding: 40px 0 20px 50px;
    }
    .slide--aprofund .body-bold {
      font-size: 38px;
      font-weight: 800;
      color: var(--white);
      line-height: 1.22;
      padding: 20px 50px 50px;
    }

    /* ─── SLIDE 6 — REVELAÇÃO (navy) ─── */
    .slide--revelacao {
      background: var(--dark-navy);
      display: flex;
      flex-direction: column;
    }
    .slide--revelacao .revelacao-headline {
      font-size: 72px;
      font-weight: 800;
      color: var(--orange);
      text-transform: uppercase;
      letter-spacing: -2px;
      line-height: 0.95;
      padding: 90px 50px 30px;
    }
    .slide--revelacao .revelacao-image {
      margin: 0 40px;
      height: 520px;
      border-radius: 4px;
      overflow: hidden;
    }
    .slide--revelacao .revelacao-body {
      font-size: 38px;
      font-weight: 800;
      color: var(--white);
      line-height: 1.22;
      padding: 40px 50px;
      flex: 1;
    }

    /* ─── SLIDE 7 — ACCOUNTABILITY (claro) ─── */
    .slide--account {
      background: var(--light-bg);
      display: flex;
      flex-direction: column;
    }
    .slide--account .account-headline {
      font-size: 68px;
      font-weight: 800;
      color: var(--orange);
      text-transform: uppercase;
      letter-spacing: -2px;
      line-height: 0.95;
      padding: 90px 50px 30px;
    }
    .slide--account .account-image {
      margin: 0 40px;
      height: 500px;
      border-radius: 4px;
      overflow: hidden;
    }
    .slide--account .account-body {
      font-size: 38px;
      font-weight: 800;
      color: var(--black);
      line-height: 1.22;
      padding: 40px 50px;
      flex: 1;
    }

    /* ─── SLIDE 8 — CTA (escuro, texto dual) ─── */
    .slide--cta {
      background: var(--dark-bg);
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    .slide--cta .arrow-wrap {
      padding: 40px 0 20px 50px;
    }
    .slide--cta .body-regular {
      font-size: 36px;
      font-weight: 500;
      color: var(--white);
      line-height: 1.35;
      padding: 0 50px;
    }
    .slide--cta .body-bold {
      font-size: 38px;
      font-weight: 800;
      color: var(--white);
      line-height: 1.35;
      padding: 30px 50px 50px;
    }

    /* ─── SLIDE 9 — CRÉDITOS (escuro) ─── */
    .slide--creditos {
      background: var(--dark-bg);
      display: flex;
      flex-direction: column;
    }
    .slide--creditos .creditos-image {
      position: absolute;
      inset: 0;
      width: 100%;
      height: 100%;
      object-fit: cover;
      z-index: 0;
    }
    .slide--creditos .gradient-overlay {
      position: absolute;
      inset: 0;
      background: linear-gradient(to top, rgba(10,14,20,0.97) 50%, rgba(10,14,20,0.3) 100%);
      z-index: 1;
    }
    .slide--creditos .accent-bar {
      position: absolute;
      left: 0; top: 0; bottom: 0;
      width: 8px;
      background: var(--orange);
      z-index: 3;
    }
    .slide--creditos .creditos-content {
      position: absolute;
      bottom: 80px;
      left: 50px;
      right: 50px;
      z-index: 3;
      display: flex;
      flex-direction: column;
      gap: 24px;
    }
    .slide--creditos .powered-badge {
      display: inline-block;
      background: var(--orange);
      color: var(--white);
      font-size: 20px;
      font-weight: 700;
      padding: 14px 28px;
      border-radius: 50px;
      text-transform: uppercase;
      letter-spacing: 1px;
      width: fit-content;
    }
    .slide--creditos .creditos-body {
      font-size: 40px;
      font-weight: 800;
      color: var(--white);
      line-height: 1.3;
    }
  </style>
</head>
<body>

  <!-- SLIDES AQUI (slide-1 a slide-9) -->

</body>
</html>
```

**4. Para cada slide, use o layout exato do design system**

Consulte `squads/ubatuba-reage/pipeline/data/design-system.md` para os mapas de layout de cada tipo de slide. Campos `[IMG]` → use `<div class="img-placeholder"><!-- [IMG] descrição da imagem --></div>` ou `<img src="assets/slideXX-NOME.jpg">` se o arquivo já existir.

**5. Salve o arquivo**

Salve em:
```
squads/ubatuba-reage/output/{run_id}/v{n}/slides/slides.html
```

Crie o diretório `slides/` e `slides/assets/` se não existirem:
```bash
mkdir -p squads/ubatuba-reage/output/{run_id}/v{n}/slides/assets
```

## Output Format

O arquivo `slides.html` deve:
- Ter exatamente 9 divs de slide (`.slide#slide-1` até `.slide#slide-9`)
- Cada div com 1080×1350px no CSS
- Header bar (`.slide-header`) em TODOS os 9 slides
- Font link para Plus Jakarta Sans
- Imagens referenciadas como `assets/slideXX-NOME.jpg` (placeholders OK se não existirem)

## Veto Conditions

- **VETO** se qualquer slide tiver dimensões diferentes de 1080×1350px no CSS
- **VETO** se o arquivo não incluir o `<link>` para Plus Jakarta Sans (Google Fonts)
- **VETO** se qualquer slide não tiver o header bar `.slide-header`
- **VETO** se o número de slides for diferente de 9
- **VETO** se usar a cor #CC0000 (a cor antiga — substituída por #FF4D00)

## Quality Criteria

- O HTML abre corretamente em qualquer browser sem erros no console
- Alternância cromática correta: Escuro → Laranja → Escuro → Laranja → Escuro → Navy → Claro → Escuro → Escuro
- Slides escuros com texto dual (3, 5, 8) têm a seta laranja separando regular de bold
- O Slide 9 tem a barra lateral de acento laranja e o badge "POWERED BY UBATUBAREAGE"
- O Slide 1 tem o logo badge circular laranja com "UBATUBA REAGE"
- Paleta de cores restrita ao design system — nenhuma cor extra
