# Task: Optimize Instagram Reels Script

## Purpose
Apply a precision optimization pass to `reels-script-draft.md` to produce the final production-ready script. Focus: hook sharpening, pacing, text overlay quality, CTA impact, and loop design.

## Input
- `squads/ubatuba-reage/output/reels-script-draft.md` — the Reel script draft
- `squads/ubatuba-reage/pipeline/data/anti-patterns.md` — what to eliminate
- `squads/ubatuba-reage/pipeline/data/quality-criteria.md` — scoring rubric

## Output
- `squads/ubatuba-reage/output/reels-script-final.md` — optimized script + change log

---

## Process

### Step 1 — Hook Test (0–2s)

Apply 3 mandatory tests to the Hook:

**Teste do Polegar:** If this frame appeared between a dog photo and a travel story in someone's feed — does it stop scrolling? Criterion: contains an unexpected fact, a specific number, or a question the Ubatuba resident cannot ignore.

**Teste do Contexto Zero:** A follower who has never heard of @ubatubareage sees this frame. Do they understand the conflict? Criterion: the hook must make sense without any prior knowledge of the profile.

**Teste da Substituição:** Remove "Ubatuba" from the hook. Does it still make full sense with any other city name? If yes — rewrite. The hook must be place-specific and irreplaceable.

If the hook fails any test, write a new version and document in the change log.

### Step 2 — Pacing Audit

Read the entire script aloud at 130–150 words per minute. Time each section:

| Seção | Alvo | Ação se fora do alvo |
|---|---|---|
| HOOK | 2s | Cortar. Nunca expandir o hook. |
| BEAT 1 | 8–12s | Acima: cortar a frase menos essencial. |
| BEAT 2 | 8–12s | Mesmo critério. |
| BEAT 3 | 5–8s | Acima: remover qualquer frase que não seja consequência direta. |
| CTA | 2–3s | Acima: simplificar para verbo + objeto + benefício. |
| **TOTAL** | **25–30s** | Se acima de 32s, cortar Beat 3 primeiro. |

Document all pacing changes.

### Step 3 — Text Overlay Quality Check

For each Text Overlay in the script:

- Count words. Maximum 8 per frame.
- Confirm it mirrors the most impactful element of the narration — not a verbatim repetition.
- Confirm it reads independently — a deaf viewer watching without audio must understand the story from overlays alone.
- Check that overlays change at a readable pace: minimum 4 seconds per frame.

If any overlay exceeds 8 words: split into two frames and add a frame-change marker.
If any overlay verbatim copies the narration: rewrite as a compressed highlight.

### Step 4 — CTA Sharpening

Evaluate the CTA against the protocol:

| Elemento | Critério |
|---|---|
| Verbo imperativo único | Uma ação: "Salva", "Compartilha", "Cobra", "Acessa" |
| Benefício imediato | Por que agir agora? |
| Máximo 10 palavras na narração | Contar explicitamente |
| Máximo 3 palavras no Text Overlay | Contar explicitamente |

If multiple actions are present: keep only the one with the highest strategic value for this Reel's objective.

### Step 5 — Loop Design Verification

Check: does the last frame visually or narratively connect back to the Hook?

Three valid loop techniques:
- **Match Cut:** final visual echoes the opening visual
- **Circular Narrative:** CTA poses the hook question as answered — viewer replays to confirm
- **Call-back Text:** last text overlay references exact words from the hook

If no loop design is present: add a loop connector to the CTA frame and document in the change log.

### Step 6 — Final Self-Score

| Dimensão | Score (1–5) | Justificativa |
|---|---|---|
| Força do Hook | | |
| Precisão Factual | | |
| Qualidade do Ritmo | | |
| Legibilidade dos Overlays | | |
| Força do CTA | | |
| **Média** | | |

Minimum: 4.0 average, Precisão Factual ≥ 4.

---

## Output Format

```
# Roteiro Reel — FINAL — [TÍTULO DA PAUTA] — @ubatubareage

Versão: Final
Data de otimização: [data]
Duração total: [N segundos]
Alterações realizadas: [N]

---

[script completo no mesmo formato do draft]

---

SCRIPT CORRIDO FINAL
[Narração completa, pronta para gravação, sem instruções]

---

NOTAS TÉCNICAS FINAIS
[Atualizadas se necessário]

CAPTION FINAL
[Caption otimizado]

---

CHANGE LOG

[Seção] ANTES: "[original]"
        DEPOIS: "[revisado]"
        MOTIVO: [razão em 1 linha]

---

SCORE FINAL
Força do Hook: X/5
Precisão Factual: X/5
Qualidade do Ritmo: X/5
Legibilidade dos Overlays: X/5
Força do CTA: X/5
Média: X.X/5

Status: [APROVADO PARA REVISÃO / REQUER REVISÃO ADICIONAL]
```

---

## Veto Conditions

1. **Média de score abaixo de 3.5:** Não entregar. Revisar dimensão mais fraca primeiro.
2. **Precisão Factual abaixo de 4:** Bloqueante absoluto.
3. **Script Corrido com instruções entre colchetes:** Remover antes de finalizar.
4. **Duração acima de 32 segundos:** Cortar antes de entregar.

---

## Quality Criteria

- Change log documenta cada alteração com antes, depois e motivo.
- Script Corrido está limpo e gravável sem edição.
- Todos os Text Overlays têm 8 palavras ou menos.
- Loop design está identificado e implementado.
- Score de Precisão Factual é >= 4/5.
