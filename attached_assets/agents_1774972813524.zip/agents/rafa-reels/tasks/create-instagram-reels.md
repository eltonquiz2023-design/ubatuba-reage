# Task: Create Instagram Reels Script

## Purpose
Write a complete, second-by-second Reel script for @ubatubareage using the user-selected editorial angle. This is a production-ready script — nothing is left as placeholder or improvised.

## Input
- `squads/ubatuba-reage/pipeline/data/selected-angle.md` — the confirmed editorial angle
- `squads/ubatuba-reage/pipeline/data/selected-news.md` — verified news story with all facts
- `squads/ubatuba-reage/pipeline/data/tone-of-voice.md` — voice and tone guide for @ubatubareage
- `squads/ubatuba-reage/pipeline/data/output-examples.md` — reference Reel examples from the profile

## Output
- `squads/ubatuba-reage/output/reels-script-draft.md` — complete Reel script ready for optimization

---

## Process

### Step 1 — Choose the Reel Format

Before writing, select the format that best fits the story and available evidence:

| Formato | Quando usar | Estrutura central |
|---|---|---|
| **"Eu Fui Lá Ver"** | Há imagens de campo (obra parada, rua, terreno) | Narrador vai ao local + mostra a realidade |
| **"Dado Revelador"** | O documento é a prova — sem imagem de campo | Texto + animação + leitura do documento |
| **"Linha do Tempo"** | Promessa antiga vs. realidade atual | Cronologia visual com cortes |
| **"Pergunta Sem Resposta"** | Prefeitura não respondeu a pedidos de informação | Sequência de "perguntamos X → silêncio" |

Document the chosen format and the reason for the choice before writing the script.

### Step 2 — Extract the 3 Narrative Beats

Every Reel has exactly 3 beats between the hook and the CTA. Identify them from the story:

- **Beat 1:** O setup — o que foi prometido ou o que deveria existir
- **Beat 2:** A quebra — quando e como a promessa ou o dever falhou
- **Beat 3:** A consequência — quem perdeu o quê, ou o que foi pago sem entrega

Each beat must be anchored in a specific fact from `selected-news.md` — not in inference or editorialization.

### Step 3 — Write the Full Script

Structure (rigid — no exceptions):

**HOOK (0–2s)**
- A single statement or question — no more than 12 words.
- Contains: a number, a place, or a revelation.
- No greeting, no logo, no "pessoal", no context.
- Visual: bold text on dark background OR immediate B-roll with text overlay.

**BEAT 1 (2–12s)**
- Script: 2–4 sentences. Narration must match the pace of the text overlays.
- Text overlay: maximum 8 words per frame. Change overlay every 5–8 seconds.
- Visual direction: specific and actionable (e.g., "gravação de tela do Portal da Transparência mostrando o contrato", não "mostre algum documento").

**BEAT 2 (12–22s)**
- Script: 2–4 sentences. The contrast or failure point.
- Text overlay: mirrors the key fact of the beat.
- Visual direction: if possible, field footage. If not, animation or screencap with red highlight.

**BEAT 3 (22–28s)**
- Script: 1–3 sentences. The consequence — who loses what.
- Text overlay: the single most impactful fact in the beat, in capitals.
- Dramatic pause: one [PAUSA] of 1 second before the CTA.

**CTA (28–30s)**
- Script: one imperative sentence. Maximum 10 words.
- Text overlay: 3 words maximum, in capitals.
- Visual: high-contrast frame (red background + white text) or direct camera.

### Step 4 — Write the Full Narration (Script Corrida)

Write the complete narration in a single block, with:
- No bracket instructions
- No speaker labels
- Natural oral rhythm — not written language read aloud
- Estimated duration when read at 130–150 words per minute

### Step 5 — Define Technical Production Notes

Specify:
- **Trilha:** type of beat (energy, mood) — no specific song titles
- **Formato de captação:** voz em off / narrador ao vivo / texto-only
- **Recursos visuais necessários:** numbered list of specific shots or assets needed
- **Loop design:** how the last frame connects back to the first

---

## Output Format

```
# Roteiro Reel — [TÍTULO DA PAUTA] — @ubatubareage

Ângulo: [nome do ângulo selecionado]
Formato: [formato escolhido no Step 1]
Duração estimada: [N segundos]
Data: [data]

---

HOOK (0–2s)
Narração: "[texto exato]"
Text Overlay: "[texto — máx. 12 palavras]"
Cena: [direção específica]

BEAT 1 — [NOME] (2–12s)
Narração: "[script exato — 2 a 4 frases]"
Text Overlay: "[texto — máx. 8 palavras por frame]"
Cena: [direção específica]

BEAT 2 — [NOME] (12–22s)
Narração: "[script exato]"
Text Overlay: "[texto]"
Cena: [direção específica]

BEAT 3 — [NOME] (22–28s)
Narração: "[script exato]"
Text Overlay: "[texto em CAPS]"
Cena: [direção específica]
[PAUSA — 1s]

CTA (28–30s)
Narração: "[frase imperativa — máx. 10 palavras]"
Text Overlay: "[máx. 3 palavras em CAPS]"
Cena: fundo vermelho, texto branco

---

SCRIPT CORRIDO (para gravação)
[Narração completa sem instruções. Pronto para gravar.]

---

NOTAS TÉCNICAS
Trilha: [tipo / mood]
Captação: [voz em off / ao vivo / texto-only]
Recursos visuais: [lista numerada]
Loop: [como o último frame conecta ao primeiro]

CAPTION DO POST
[150–250 caracteres + hashtags]
```

---

## Veto Conditions

1. **Hook com saudação ou intro:** Se o script começa com "Oi pessoal", "Olá", logo animado ou qualquer tipo de introdução antes do conflito — reescrever antes de gerar o arquivo.
2. **Script corrido com instruções entre colchetes:** O Script Corrido é exclusivamente narração. Se contiver [PAUSA], [ÊNFASE] ou qualquer outra instrução — remover antes de finalizar o arquivo.
3. **Duração acima de 35 segundos:** Contar o texto corrido em 130 palavras/minuto. Se ultrapassar 35s, cortar de Beat 3 ou compactar Beats 1–2.
4. **Text Overlay com mais de 8 palavras por frame:** Contar explicitamente. Legendas longas não são lidas no tempo de um corte — dividir em dois frames se necessário.

---

## Quality Criteria

- O HOOK para o scroll sem contexto prévio e comunica o conflito em 2 segundos.
- Cada Beat tem direção de cena específica e acionável — não genérica.
- O Script Corrido pode ser gravado por uma pessoa sem hesitação ou improviso.
- O último frame conecta visualmente ou narrativamente ao primeiro — loop planejado.
- O CTA especifica exatamente uma ação e o benefício de realizá-la.
