---
name: diagnose-community
description: Avalia conteudo nas dimensoes Friccao, Mobilizacao, Identidade e Utilidade com nota 0-10 sob a perspectiva do morador de Ubatuba.
---

# Task: Diagnostico Comunitario

## Input

- Carrossel aprovado: `squads/ubatuba-reage/output/{run_id}/v{n}/instagram-feed-draft.md`
- Roteiro Reel: `squads/ubatuba-reage/output/{run_id}/v{n}/reels-script-draft.md`
- Rubrica: `squads/ubatuba-reage/pipeline/data/curadoria-criterios.md`
- Noticia base: `squads/ubatuba-reage/pipeline/data/selected-news.md`

## Processo

1. Leia a rubrica completa de 10 dimensoes.
2. Vista a pele do morador de Ubatuba. Avalie CADA peca nas suas 4 dimensoes:

### Friccao (peso 10%)
- O conteudo gera desconforto civico? O morador sente que PRECISA agir?
- Tem tensao narrativa ou e so informativo?
- Evita fadiga de indignacao? (denuncia + acao, nunca so denuncia)

### Mobilizacao (peso 12%)
- CTA com 3 acoes concretas?
- Frase pronta entre aspas para copiar e enviar ao vereador?
- Link funcional para o documento publico?
- Prazo ou urgencia clara?

### Identidade (peso 8%)
- Reconhecivel como @ubatubareage em 2 segundos?
- Menciona Ubatuba especificamente (bairros, ruas, equipamentos)?
- Tom alinhado com "Indignacao Construtiva"?
- Linguagem do dia a dia do litoral norte?

### Utilidade (peso 7%)
- O seguidor sai com ferramenta pratica?
- Link verificavel? Data de evento? Contato de vereador?
- A frase pronta e realista (alguem de fato enviaria)?

3. Para cada dimensao, forneca:
   - Nota 0-10 com justificativa
   - Citacao de trecho exato
   - Proposta de melhoria sob a otica do morador

## Formato de Output

```markdown
# Diagnostico Comunitario -- Lucia Local

## Carrossel

### Friccao -- [X]/10
**Diagnostico:** [2-3 frases, perspectiva do morador]
**Trecho:** Slide [N]: "[citacao exata]"
**O morador diria:** "[reacao esperada do morador ao ler]"
**Para chegar a 10:** [sugestao especifica]

### Mobilizacao -- [X]/10
[mesmo formato]

### Identidade -- [X]/10
[mesmo formato]

### Utilidade -- [X]/10
[mesmo formato]

## Reel

[mesmo formato para as 4 dimensoes]

## Proposta de Reescrita

[Blocos que precisam mudar, com foco em tornar o conteudo mais acionavel para o morador]

## Impacto Estimado

[Quais dimensoes sobem e quantos pontos]
```

## Veto Conditions

- VETO se avaliar como academico em vez de como morador
- VETO se propor CTA elitista sem link direto
- VETO se ignorar que o publico principal e classe C/D

## Quality Criteria

- Perspectiva genuina de morador, nao de analista
- CTAs propostos sao de baixo esforco e alto impacto
- Identidade local presente nas sugestoes (bairros, referencias locais)
