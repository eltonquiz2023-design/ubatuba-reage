---
name: diagnose-strategy
description: Avalia conteudo nas dimensoes Gancho, Compartilhabilidade, Prova e Ritmo com foco em performance digital e projecao de ER.
---

# Task: Diagnostico Estrategico

## Input

- Carrossel aprovado: `squads/ubatuba-reage/output/{run_id}/v{n}/instagram-feed-draft.md`
- Roteiro Reel: `squads/ubatuba-reage/output/{run_id}/v{n}/reels-script-draft.md`
- Rubrica: `squads/ubatuba-reage/pipeline/data/curadoria-criterios.md`
- Noticia base: `squads/ubatuba-reage/pipeline/data/selected-news.md`
- Benchmarks: `squads/ubatuba-reage/pipeline/data/quality-criteria.md`

## Processo

1. Leia a rubrica e os benchmarks do perfil.
2. Avalie CADA peca nas suas 4 dimensoes com foco em performance:

### Gancho (peso 15%)
- Hook para o scroll nos primeiros 2s (Reel) ou no slide 1 (carrossel)?
- Numero concreto na abertura? (posts com numero no hook tem +23% ER no perfil)
- Funciona como thumbnail a 200px?
- Comparar com hooks dos top posts do perfil.

### Compartilhabilidade (peso 5%)
- Projetado para SALVAR e COMPARTILHAR, nao apenas curtir?
- Slide 1 funciona standalone como imagem de compartilhamento?
- Dados impactantes que motivam "preciso mostrar isso"?
- Loop no Reel (frame final conecta ao inicial)?

### Prova (peso 15%)
- 100% verificado com fonte visivel no slide?
- URLs publicas acessiveis?
- Estimativas claramente marcadas como estimativas?
- Numeros consistentes entre carrossel e reel?

### Ritmo (peso 8%)
- Alternancia cromatica obedece a sequencia do design system?
- Nenhum slide acima de 80 palavras?
- Reel: cortes a cada 3-5s? Duracao 15-30s?
- Reel: loop seamless?

3. Para cada dimensao, forneca:
   - Nota 0-10 com justificativa baseada em benchmarks
   - Comparacao com posts historicos do perfil
   - Projecao de impacto na metrica

## Formato de Output

```markdown
# Diagnostico Estrategico -- Bia Boost

## Carrossel

### Gancho -- [X]/10
**Diagnostico:** [2-3 frases com referencia a benchmarks]
**Benchmark:** [comparacao com post historico mais proximo]
**Trecho:** Slide [N]: "[citacao exata]"
**Para chegar a 10:** [sugestao com projecao de impacto em ER]

### Compartilhabilidade -- [X]/10
[mesmo formato]

### Prova -- [X]/10
[mesmo formato]

### Ritmo -- [X]/10
[mesmo formato]

## Reel

[mesmo formato para as 4 dimensoes]

## Projecao de Performance

| Peca | ER Estimado | Alcance Estimado | Referencia |
|---|---|---|---|
| Carrossel | [X%-Y%] | [XXk-YYYk] | [post de referencia] |
| Reel | [X%-Y%] | [XXk-YYYk] | [post de referencia] |

## Proposta de Reescrita

[Mudancas com maior impacto em ER, ordenadas por ROI]

## Impacto Estimado

[Quais dimensoes sobem e quantos pontos. Projecao de delta no ER.]
```

## Veto Conditions

- VETO se projecao de ER nao for baseada em benchmarks reais do perfil
- VETO se otimizar para likes em vez de saves/shares
- VETO se ignorar consistencia numerica entre carrossel e reel

## Quality Criteria

- Toda projecao tem benchmark de referencia
- Foco em saves e shares, nao likes
- Propostas ordenadas por impacto esperado em ER
