---
name: create-stories-sequence
description: Gera sequencia de 3-5 Instagram Stories com copy, stickers interativos, links e direcao visual para amplificar o post principal.
---

# Task: Criar Sequencia de Stories

## Input

- Carrossel aprovado: `squads/ubatuba-reage/output/{run_id}/v{n}/instagram-feed-draft.md`
- Roteiro Reel: `squads/ubatuba-reage/output/{run_id}/v{n}/reels-script-draft.md`
- Legendas: `squads/ubatuba-reage/output/{run_id}/v{n}/captions.md`
- Noticia base: `squads/ubatuba-reage/pipeline/data/selected-news.md`
- Tom de voz: `squads/ubatuba-reage/pipeline/data/tone-of-voice.md`

## Processo

### 1. Definir Objetivo da Sequencia

Baseado no conteudo principal, defina o objetivo da sequencia de Stories:

| Tipo de Conteudo | Objetivo Stories | Sticker Principal |
|---|---|---|
| Denuncia | Amplificar + link pro documento | Link sticker + Enquete |
| Urgencia (votacao) | Mobilizar + contagem regressiva | Countdown + Link |
| Investigativo | Bastidores + verificacao | Pergunta aberta + Link |
| Empoderamento | Tutorial interativo | Quiz + Link |
| Memoria | Timeline + cobranca | Enquete + Mencao |

### 2. Criar Sequencia de 3-5 Stories

**Story 1 -- Hook Interativo**
- Dado impactante do post em texto grande (max 3 linhas)
- Sticker: Enquete ("Voce sabia disso? Sim / Nao") ou Quiz
- Visual: Fundo solido laranja ou escuro com texto bold
- Funcao: Capturar atencao + gerar primeira interacao

**Story 2 -- Contexto + Link**
- 2-3 frases de contexto que NAO estao no carrossel/reel
- Sticker: Link para documento publico fonte
- Visual: Screenshot do documento com marca-texto ou fundo com texto
- Funcao: Direcionar ao documento + credibilidade

**Story 3 -- CTA Direto**
- Acao concreta que o seguidor pode tomar AGORA
- Sticker: Contagem regressiva (se evento) ou Link (se acao online) ou Mencao (se cobranca)
- Visual: Texto grande com seta indicando o sticker
- Funcao: Converter espectador em cidadao ativo

**Story 4 (opcional) -- Bastidores**
- Como o @ubatubareage descobriu essa informacao
- Sticker: Pergunta aberta ("O que voce acha?") ou Slider de reacao
- Visual: Mais informal, tom de "camera de celular"
- Funcao: Humanizar o movimento + gerar UGC nos replies

**Story 5 (opcional) -- Repost/Resultado**
- Reacao da comunidade ou resultado da enquete
- Sticker: Mencao ao post principal ("Veja o carrossel completo")
- Visual: Print do resultado da enquete + texto de comentario
- Funcao: Social proof + direcionar ao post principal

### 3. Especificar Cada Story

Para cada Story, defina:
- Copy: texto exato (max 3 linhas, fonte grande)
- Sticker: tipo + configuracao (opcoes da enquete, URL do link, data da contagem)
- Visual: direcao de fundo/imagem
- Posicao dos elementos: onde cada texto e sticker ficam na tela

## Formato de Output

```markdown
# Stories -- {titulo_pauta}

**Objetivo:** {objetivo da sequencia}
**Quantidade:** {N} Stories
**Publicar:** {antes / junto / apos o post principal}

---

## Story 1/N -- Hook Interativo

**Copy:**
{texto em max 3 linhas}

**Sticker:** {tipo}
- {configuracao: opcoes, URL, data, etc}

**Visual:**
- Fundo: {cor solida / imagem / screenshot}
- Tipografia: {bold nativa / highlight}
- Posicao: {texto no topo, sticker no centro, etc}

**Funcao:** {capturar atencao / gerar interacao / etc}

---

## Story 2/N -- Contexto + Link
[mesmo formato]

---

## Story 3/N -- CTA Direto
[mesmo formato]

---

## Timing

| Story | Publicar | Intervalo |
|---|---|---|
| 1 | {horario relativo ao post} | - |
| 2 | +5min apos Story 1 | 5min |
| 3 | +5min apos Story 2 | 5min |

## Metricas Esperadas

- Taxa de conclusao da sequencia: > 60%
- Interacao com stickers: > 15% dos espectadores
- Cliques no link: > 5% dos espectadores
```

## Veto Conditions

- VETO se Story repetir conteudo do carrossel/reel na integra
- VETO se nenhum Story tiver sticker interativo
- VETO se sequencia tiver mais de 7 Stories
- VETO se link sticker apontar para pagina generica

## Quality Criteria

- Sequencia de 3-5 Stories (sweet spot)
- Cada Story tem pelo menos 1 sticker interativo
- Link sticker aponta para documento publico especifico
- Funciona standalone (seguidor que nao viu o post entende)
- Tom mais intimo e urgente que o feed
- Contagem regressiva presente quando ha evento com data
