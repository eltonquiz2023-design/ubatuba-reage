# Task: Generate Feedback Report

## Purpose
Produce the complete, publication-blocking review report for both content pieces. This is the final gate before publication: scoring tables, detailed feedback, mandatory changes (if any), and the official veredito.

## Input
- Scoring tables from `score-content.md`
- `squads/ubatuba-reage/output/instagram-feed-final.md`
- `squads/ubatuba-reage/output/reels-script-final.md`
- `squads/ubatuba-reage/pipeline/data/quality-criteria.md`

## Output
- `squads/ubatuba-reage/output/review-report.md` -- complete review report with official veredito

---

## Process

### Step 1 -- Determine the Veredito

Based on the scoring tables from `score-content.md`:

| Condicao | Veredito |
|---|---|
| Todas as medias >= 4.0 AND F-score >= 4 em ambas as pecas AND sem anti-patterns bloqueantes | APROVADO |
| Media >= 3.5 AND F-score >= 4 AND anti-patterns nao-bloqueantes apenas | APROVADO CONDICIONAL |
| Qualquer media < 3.5 OR F-score < 4 em qualquer peca OR qualquer anti-pattern bloqueante | REJEITADO |

The veredito is determined by the weaker of the two pieces.

### Step 2 -- Build the Detailed Feedback

For each piece, for each FACT dimension:

```
Dimensao: [F/A/C/T]
Score: X/5
Ponto forte: "[o que funciona -- trecho especifico]"
[Se score < 5:]
Mudanca obrigatoria: [apenas se bloqueante -- o que, onde, como corrigir]
Sugestao (nao-bloqueante): [se apenas uma melhoria de qualidade]
```

Rules:
- Every entry has a Ponto forte -- even score 1/5. Find what works.
- "Mudanca obrigatoria:" only for issues that change the veredito if fixed.
- "Sugestao (nao-bloqueante):" for quality improvements that do not affect the veredito.
- Never use ambiguous language for mandatory changes.

### Step 3 -- Build the Mandatory Changes List (if REJEITADO or APROVADO CONDICIONAL)

Numbered list for each mandatory change:
- Piece affected (Carrossel / Reel)
- Exact location (Slide X, linha Y / Beat N, narracao)
- Current text
- Required correction or instruction
- Why this change is blocking

### Step 4 -- Write the Caminho para Aprovacao (if REJEITADO)

1. List mandatory changes in order of blocking severity (F-score issues first)
2. Estimate the scope of revision
3. State what does NOT need to change (protect what works)
4. Note: "Revisao [N/3] -- [N] ciclos restantes antes de escalar"

### Step 5 -- Add the Escalation Note (Ciclo 3/3 only)

If this is the third revision of the same content, add to the report header:

```
ATENCAO -- CICLO MAXIMO ATINGIDO
Esta e a 3a revisao deste conteudo. Os problemas persistentes estao listados abaixo.
Uma decisao editorial e necessaria: publicar com ressalvas, descartar esta pauta,
ou escalar para revisao humana.
Vera nao iniciara um 4o ciclo de revisao deste conteudo.
```

---

## Output Format

```
# Relatorio de Revisao -- @ubatubareage
Pauta: [titulo]
Data: [data]
Ciclo: [N/3]
Revisora: Vera Veredito

---

## VEREDITO

[APROVADO / APROVADO CONDICIONAL / REJEITADO]

[1-2 linhas de justificativa]

---

## TABELA DE SCORES

### Carrossel (Feed)
| Dimensao | Score | Citacao | Local |
|---|---|---|---|
| F -- Fatos | X/5 | "[trecho]" | Slide X |
| A -- Atribuicao | X/5 | "[trecho]" | Slide X |
| C -- Clareza | X/5 | "[trecho]" | Slide X |
| T -- Tom | X/5 | "[trecho]" | Slide X |
| Media | X.X/5 | | |

### Reel
| Dimensao | Score | Citacao | Local |
|---|---|---|---|
| F -- Fatos | X/5 | "[trecho]" | Beat X |
| A -- Atribuicao | X/5 | "[trecho]" | Beat X |
| C -- Clareza | X/5 | "[trecho]" | Beat X |
| T -- Tom | X/5 | "[trecho]" | Beat X |
| Media | X.X/5 | | |

---

## FEEDBACK DETALHADO

### Carrossel

F -- Fatos (X/5)
Ponto forte: "[trecho especifico]"
[Mudanca obrigatoria: ou Sugestao (nao-bloqueante):]

A -- Atribuicao (X/5)
Ponto forte: "[trecho especifico]"

C -- Clareza (X/5)
Ponto forte: "[trecho especifico]"

T -- Tom (X/5)
Ponto forte: "[trecho especifico]"

### Reel
[Mesma estrutura]

---

## MUDANCAS OBRIGATORIAS (se houver)

1. [Carrossel / Reel] -- [Localizacao exata]
   Atual: "[texto atual]"
   Corrigir para: "[instrucao exata]"
   Motivo: [por que bloqueia]

---

## POTENCIAL DE ENGAJAMENTO

Carrossel: [faixa ER estimada] -- comparavel a: [benchmark]
Reel: [faixa ER estimada] -- comparavel a: [benchmark]

---

## CAMINHO PARA APROVACAO (se REJEITADO)

[Acoes em ordem de prioridade]
[O que NAO precisa mudar]
Ciclos restantes: N
```

---

## Veto Conditions

1. **Veredito inconsistente com scores:** Se F-score e 2/5 mas veredito e APROVADO -- corrigir antes de emitir.
2. **Mudanca obrigatoria sem localizacao exata:** Especificar peca + slide/beat + linha + trecho + correcao.
3. **Ciclo 3 sem escalation note:** O bloco de escalacao e obrigatorio no terceiro ciclo.

---

## Quality Criteria

- O veredito e consistente com os scores -- sem contradicao entre tabela e resultado final.
- Cada "Mudanca obrigatoria:" tem localizacao exata e instrucao de correcao especifica.
- Cada dimensao tem pelo menos um "Ponto forte:" com citacao de trecho especifico.
- O numero do ciclo esta declarado no cabecalho.
- O relatorio e auto-contido -- quem o recebe sem contexto sabe o que mudar e por que.
