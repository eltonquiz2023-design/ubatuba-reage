# Task: Score Content

## Purpose
Apply the FACT framework to produce a structured scoring table for both the carousel (`instagram-feed-draft.md`) and the Reel script (`reels-script-draft.md`). This produces the quantitative foundation that the next task (`generate-feedback.md`) uses to build the full review report.

## Input
- `squads/ubatuba-reage/output/instagram-feed-draft.md` — the carousel approved at step-08
- `squads/ubatuba-reage/output/reels-script-draft.md` — the Reel script approved at step-08
- `squads/ubatuba-reage/pipeline/data/quality-criteria.md` — scoring rubric and benchmarks
- `squads/ubatuba-reage/pipeline/data/anti-patterns.md` — list of disqualifying patterns
- `squads/ubatuba-reage/pipeline/data/selected-news.md` — source story for fact-checking

## Output
- Internal: scoring tables used directly in `generate-feedback.md` — no separate file needed

---

## Process

### Step 1 — Load and Confirm Source Facts

Before scoring anything, extract the verified facts from `selected-news.md`:

- Every monetary value (R$) and its source URL
- Every date and its document reference
- Every named person, their official title, and the document naming them
- Every statistic and its origin

This is the fact-checking baseline. Any claim in the content that cannot be mapped to this list is flagged as unverified.

### Step 2 — Score the Carousel (instagram-feed-final.md)

Apply the FACT framework to the carousel. Score each dimension on a 1–5 scale:

**F — Fatos (Factual Accuracy)**
For each slide containing a number, date, or monetary value:
- Is the value identical to the source in `selected-news.md`?
- Is the source visible within the slide itself (not only in the caption)?
- Is the equivalência humana (R$ X = Y) accurate and verifiable?

Score 5: all data verified, all sources visible, all equivalências accurate.
Score 4: one minor data presentation issue (source in caption only, not in slide).
Score 3: one data point unverified or missing source.
Score 2: two or more unverified data points.
Score 1: fabricated or significantly inaccurate data.

**A — Atribuição (Attribution)**
For each claim about a person, contract, or institution:
- Is the responsible party identified by name and role?
- Is the claim supported by a named, accessible public document?
- Is there any risk of defamation (claim without documentary backing)?

Score 5: all attributions have named documents with URLs.
Score 4: attributions are correct but one document URL is missing.
Score 3: one attribution lacks documentary support.
Score 2: claims about named individuals without documentation.
Score 1: unsubstantiated accusations against identified individuals — LEGAL RISK FLAG mandatory.

**C — Clareza (Clarity)**
Does a Ubatuba resident with no prior knowledge of the story understand the denúncia after reading the carousel?
- Is the central fact clear by Slide 2?
- Is the responsible party identified by Slide 5?
- Is the concrete impact (who loses what) stated before the CTA?
- Is the CTA specific enough to be executed without additional research?

Score 5: all four elements clear and in correct sequence.
Score 4: one element slightly unclear or out of order.
Score 3: two elements unclear.
Score 2: central fact or responsible party not clearly identified.
Score 1: story is incomprehensible to someone not already informed.

**T — Tom (Tone)**
Is the carousel within the "Indignação Construtiva" standard?
- Raiva direcionada ao fato/instituição — não ao leitor
- Ação proposta junto com a denúncia
- Sem linguagem partidária, sem ataques ad hominem sem base documental
- Sem alarmismo sem solução ("estamos perdidos", "nada vai mudar")

Score 5: perfect alignment with Indignação Construtiva.
Score 4: one phrase slightly off-tone (easily fixed).
Score 3: two or more off-tone phrases.
Score 2: significant tone problem affecting credibility.
Score 1: content that would embarrass the @ubatubareage brand publicly.

### Step 3 — Score the Reel (reels-script-final.md)

Apply the same FACT framework to the Reel script:

**F — Fatos:** Same criteria as carousel. Pay special attention to numbers spoken in narration — must match source exactly, as spoken errors are harder to correct post-publication.

**A — Atribuição:** In Reels, attributions appear as both narration AND text overlays. Both must be consistent and accurate. If a name appears only in narration but not in overlay — flag for clarity (not necessarily a FACT fail).

**C — Clareza:** Can a Ubatuba resident understand the story watching with no audio (subtitles only)? The text overlays must carry the full story independently of narration.

**T — Tom:** Additional Reel-specific check: does the Hook create urgency without resorting to alarmism? Does the CTA specify one action without sounding threatening or desperate?

### Step 4 — Anti-Pattern Check

Scan both pieces against `anti-patterns.md`. Flag each occurrence with:
- Location (Slide X, Line Y / Reel Beat N, narration)
- The anti-pattern detected
- Severity: Bloqueante / Não-bloqueante

Anti-patterns that are always Bloqueante:
- Dado sem fonte visível no slide (carousel)
- CTA múltiplo no último slide/frame
- Script do Reel corrido com instruções entre colchetes
- Fonte apenas na legenda, não no slide

### Step 5 — ER Potential Assessment

Based on the @ubatubareage benchmarks from `quality-criteria.md`:
- "Obras Prometidas" Reel: 15.34% ER
- "Futuro Ubatuba" Carousel: 14.33% ER
- "Denúncia Tenório" Reel: 11.89% ER, 2.3M reach

Assess which benchmark this content most closely resembles and estimate the ER potential range (e.g., 8–12%, 12–15%, 15%+). Document the reasoning: what specific elements are driving the estimate up or down.

---

## Output Format (Internal — passed directly to generate-feedback.md)

```
=== SCORING TABLES — [TÍTULO DA PAUTA] ===
Data da revisão: [data]
Ciclo de revisão: [N/3]

--- CARROSSEL ---

| Dimensão | Score | Citação de Trecho | Localização |
|---|---|---|---|
| F — Fatos | X/5 | "[trecho exato]" | Slide X |
| A — Atribuição | X/5 | "[trecho exato]" | Slide X |
| C — Clareza | X/5 | "[trecho exato]" | Slide X |
| T — Tom | X/5 | "[trecho exato]" | Slide X |
| **Média** | **X.X/5** | | |

Anti-patterns detectados no carrossel:
- [Slide X] "[trecho]" — [padrão] — [Bloqueante/Não-bloqueante]

ER Potential (carrossel): [faixa estimada] — motivo: [razão em 1 linha]

--- REEL ---

| Dimensão | Score | Citação de Trecho | Localização |
|---|---|---|---|
| F — Fatos | X/5 | "[trecho exato]" | [Beat/CTA] |
| A — Atribuição | X/5 | "[trecho exato]" | [Beat/CTA] |
| C — Clareza | X/5 | "[trecho exato]" | [Beat/CTA] |
| T — Tom | X/5 | "[trecho exato]" | [Beat/CTA] |
| **Média** | **X.X/5** | | |

Anti-patterns detectados no reel:
- [Beat X] "[trecho]" — [padrão] — [Bloqueante/Não-bloqueante]

ER Potential (reel): [faixa estimada] — motivo: [razão em 1 linha]

--- LEGAL FLAGS ---
[Se F ou A < 3 em qualquer peça]
RISCO LEGAL: [afirmação exata] — [slide/beat] — [documento necessário]
```

---

## Veto Conditions

1. **F — Fatos score 1 em qualquer peça:** Scoring não avança para generate-feedback.md. Vera sinaliza ao usuário que o conteúdo contém dado fabricado ou significativamente impreciso — revisão não pode prosseguir até correção.
2. **Legal flag sem resolução:** Se uma afirmação sobre pessoa identificada não tem amparo documental, Vera emite o flag e aguarda. Não gera o relatório de feedback até que o criador confirme a fonte ou remova a afirmação.

---

## Quality Criteria

- Cada score tem pelo menos uma citação de trecho com localização específica (Slide X / Beat Y).
- Anti-patterns são identificados com localização e severidade — nunca listados sem endereço no conteúdo.
- ER potential assessment é baseado em comparação explícita com os benchmarks reais do perfil.
- O ciclo de revisão está declarado no cabeçalho (ex: "Ciclo 1/3").
