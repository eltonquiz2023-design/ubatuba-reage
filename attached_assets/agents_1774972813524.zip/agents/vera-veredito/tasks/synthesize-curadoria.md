---
name: synthesize-curadoria
description: Sintetiza os 3 diagnosticos (editorial, comunitario, estrategico) em scorecard ponderado de 10 dimensoes, emite veredito e aciona auto-correcao se score < 8.
---

# Task: Sintese de Curadoria

## Input

- Diagnostico Editorial: `squads/ubatuba-reage/output/{run_id}/v{n}/diagnostico-editorial.md` (Carlos Curador)
- Diagnostico Comunitario: `squads/ubatuba-reage/output/{run_id}/v{n}/diagnostico-comunitario.md` (Lucia Local)
- Diagnostico Estrategico: `squads/ubatuba-reage/output/{run_id}/v{n}/diagnostico-estrategico.md` (Bia Boost)
- Rubrica: `squads/ubatuba-reage/pipeline/data/curadoria-criterios.md`
- Review Report (Vera): `squads/ubatuba-reage/output/{run_id}/v{n}/review-report.md`

## Processo

### 1. Consolidar Scores das 3 Perspectivas

Para cada uma das 10 dimensoes, extraia as notas dos diagnosticos que a cobrem:

| Dimensao | Peso | Avaliado por |
|---|---|---|
| Gancho | 15% | Carlos + Bia |
| Friccao | 10% | Lucia |
| Prova | 15% | Bia |
| Narrativa | 10% | Carlos |
| Mobilizacao | 12% | Lucia |
| Clareza | 10% | Carlos |
| Ritmo | 8% | Carlos + Bia |
| Identidade | 8% | Lucia |
| Utilidade | 7% | Lucia |
| Compartilhabilidade | 5% | Bia |

Quando uma dimensao e avaliada por 2 agentes, use a media das duas notas.

### 2. Calcular Score Ponderado

```
Score Final = Sum(nota_dimensao * peso_dimensao)
```

### 3. Resolver Conflitos

Se dois agentes divergem em mais de 3 pontos na mesma dimensao:
- Cite ambas as justificativas com trechos
- Aplique o principio mais conservador (nota menor)
- Registre a divergencia no relatorio

### 4. Integrar com Review FACT de Vera

O score FACT (do review-report.md) tem poder de veto:
- Se F-score < 4/5 no FACT: REJEITADO independente do score de curadoria
- Se RISCO LEGAL flagged: REJEITADO independente do score de curadoria
- O score FACT e o score de curadoria devem ser consistentes no relatorio final

### 5. Determinar Veredito

| Score Final | Veredito |
|---|---|
| >= 9.0 | APROVADO |
| 8.0 - 8.9 | APROVADO CONDICIONAL |
| < 8.0 | REJEITADO — aciona auto-correcao |

### 6. Auto-Correcao (se score < 8.0)

Se REJEITADO e ciclo < 3/3:
1. Compile as mudancas obrigatorias dos 3 diagnosticos + review FACT
2. Ordene por impacto no score ponderado (maior peso primeiro)
3. Gere instrucoes de correcao especificas para o agente criador
4. Incremente o ciclo de revisao

Se ciclo = 3/3 e score < 9.0:
- Escale ao usuario com relatorio completo
- Inclua nota: "Ciclo 3/3 — decisao do usuario necessaria"

## Formato de Output

```markdown
# Scorecard de Curadoria — {titulo_pauta}

**Ciclo:** {N}/3
**Data:** {data}
**Score Final:** {X.X}/10
**Veredito:** {APROVADO | APROVADO CONDICIONAL | REJEITADO}

## Scorecard por Dimensao

### Carrossel

| Dimensao | Peso | Nota | Ponderado | Avaliador(es) | Justificativa |
|---|---|---|---|---|---|
| Gancho | 15% | X/10 | X.XX | Carlos + Bia | [resumo com trecho] |
| Friccao | 10% | X/10 | X.XX | Lucia | [resumo com trecho] |
| Prova | 15% | X/10 | X.XX | Bia | [resumo com trecho] |
| Narrativa | 10% | X/10 | X.XX | Carlos | [resumo com trecho] |
| Mobilizacao | 12% | X/10 | X.XX | Lucia | [resumo com trecho] |
| Clareza | 10% | X/10 | X.XX | Carlos | [resumo com trecho] |
| Ritmo | 8% | X/10 | X.XX | Carlos + Bia | [resumo com trecho] |
| Identidade | 8% | X/10 | X.XX | Lucia | [resumo com trecho] |
| Utilidade | 7% | X/10 | X.XX | Lucia | [resumo com trecho] |
| Compartilhabilidade | 5% | X/10 | X.XX | Bia | [resumo com trecho] |
| **TOTAL** | **100%** | | **X.XX** | | |

### Reel

[mesmo formato]

## Divergencias entre Avaliadores

[Se houver divergencia > 3 pontos, listar com justificativas de ambos]

## Integracao com Review FACT

| Dimensao FACT | Score | Status |
|---|---|---|
| F — Fatos | X/5 | OK / FLAG |
| A — Atribuicao | X/5 | OK / FLAG |
| C — Clareza | X/5 | OK / FLAG |
| T — Tom | X/5 | OK / FLAG |

## Pontos Fortes

1. [Ponto forte com localizacao e impacto]
2. [Ponto forte com localizacao e impacto]

## Mudancas Obrigatorias (se REJEITADO ou APROVADO CONDICIONAL)

1. **[ID]** [Localizacao]: [O que mudar] — Impacto: +X.X no score ponderado
2. **[ID]** [Localizacao]: [O que mudar] — Impacto: +X.X no score ponderado

## Sugestoes (nao-bloqueantes)

1. [Sugestao com localizacao e impacto estimado]

## Projecao de ER

| Peca | ER Atual Estimado | ER Pos-Correcao | Benchmark |
|---|---|---|---|
| Carrossel | X%-Y% | X%-Y% | [post referencia] |
| Reel | X%-Y% | X%-Y% | [post referencia] |

## Caminho para Aprovacao (se REJEITADO)

[Instrucoes ordenadas por impacto para o agente criador atingir score >= 9.0]
```

## Veto Conditions

- VETO se emitir veredito sem integrar o review FACT de Vera
- VETO se calcular score sem usar os pesos definidos na rubrica
- VETO se aprovar conteudo com F-score < 4/5 no FACT
- VETO se entrar em ciclo 4 — escalar ao usuario

## Quality Criteria

- Score final e matematicamente correto (soma dos ponderados)
- Cada nota tem justificativa com citacao de trecho
- Divergencias entre avaliadores sao registradas e resolvidas
- Mudancas obrigatorias tem impacto estimado no score
- Projecao de ER baseada em benchmarks reais do perfil
- Ciclo de revisao declarado no cabecalho
