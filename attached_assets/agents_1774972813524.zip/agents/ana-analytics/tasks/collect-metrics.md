---
name: collect-metrics
description: Coleta metricas reais do post publicado nas 3 janelas temporais (24h, 48h, 7d) via input manual ou API.
---

# Task: Coletar Metricas

## Input

- Conteudo publicado: `squads/ubatuba-reage/output/{run_id}/v{n}/instagram-feed-draft.md`
- Scorecard de curadoria: `squads/ubatuba-reage/output/{run_id}/v{n}/curadoria-scorecard.md`
- Projecao de ER: extraida do scorecard (secao "Projecao de Performance")
- Metricas reais: fornecidas pelo usuario (Instagram Insights ou input manual)

## Processo

### 1. Solicitar Metricas ao Usuario

Pergunte ao usuario as metricas do post para a janela temporal atual:

**Metricas obrigatorias:**
- Alcance (accounts reached)
- Impressoes
- Curtidas
- Comentarios
- Compartilhamentos (sends)
- Salvamentos (saves)
- Visitas ao perfil (profile visits)
- Cliques no link (se aplicavel)

**Metricas opcionais (Reels):**
- Visualizacoes
- Taxa de conclusao (completion rate)
- Replays

### 2. Calcular KPIs Derivados

```
ER = (curtidas + comentarios + compartilhamentos + salvamentos) / alcance * 100
Save Rate = salvamentos / alcance * 100
Share Rate = compartilhamentos / alcance * 100
Engagement por Seguidor = (curtidas + comentarios + compartilhamentos + salvamentos) / seguidores * 100
```

### 3. Registrar na Janela Temporal

Marque a janela atual (24h, 48h, ou 7d) e registre todos os dados.

## Formato de Output

```markdown
# Metricas -- {titulo_pauta} -- {janela}h

**Post:** {tipo: carrossel/reel}
**Publicado em:** {data e hora}
**Coletado em:** {data e hora} ({janela}h pos-publicacao)

## Metricas Brutas

| Metrica | Valor |
|---|---|
| Alcance | {N} |
| Impressoes | {N} |
| Curtidas | {N} |
| Comentarios | {N} |
| Compartilhamentos | {N} |
| Salvamentos | {N} |
| Visitas ao perfil | {N} |
| Cliques no link | {N} |

## KPIs Derivados

| KPI | Valor | Benchmark Perfil |
|---|---|---|
| ER | {X.XX}% | 14%+ (meta ideal) |
| Save Rate | {X.XX}% | {media do perfil} |
| Share Rate | {X.XX}% | {media do perfil} |

## Status da Coleta

- [x] 24h
- [ ] 48h
- [ ] 7d
```

## Quality Criteria

- Todas as metricas obrigatorias coletadas
- KPIs derivados calculados corretamente
- Janela temporal identificada com precisao
- Dados nao estimados -- reais do Instagram Insights
