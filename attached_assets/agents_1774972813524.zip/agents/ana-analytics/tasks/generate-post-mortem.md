---
name: generate-post-mortem
description: Compara projecao de ER vs resultado real, identifica padroes e gera recomendacoes acionaveis para proximas runs.
---

# Task: Gerar Post-Mortem

## Input

- Metricas coletadas: `squads/ubatuba-reage/output/{run_id}/v{n}/metrics-7d.md`
- Scorecard de curadoria: `squads/ubatuba-reage/output/{run_id}/v{n}/curadoria-scorecard.md`
- Review report: `squads/ubatuba-reage/output/{run_id}/v{n}/review-report.md`
- Carrossel: `squads/ubatuba-reage/output/{run_id}/v{n}/instagram-feed-draft.md`
- Reel: `squads/ubatuba-reage/output/{run_id}/v{n}/reels-script-draft.md`
- Benchmarks: `squads/ubatuba-reage/pipeline/data/quality-criteria.md`

## Processo

### 1. Calcular Delta Projecao vs Realidade

Para cada peca (carrossel e reel):
- ER projetado (do scorecard de curadoria)
- ER real (das metricas 7d)
- Delta em pontos percentuais
- Classificacao: Acima (+3pp ou mais), Alinhado (+-3pp), Abaixo (-3pp ou mais)

### 2. Atribuir Performance a Dimensoes

Analise qual(is) dimensao(oes) da curadoria mais influenciaram o resultado:

**Se performance ACIMA do projetado:**
- Qual dimensao com nota alta mais provavelmente impulsionou? (priorizar Gancho, Compartilhabilidade, Mobilizacao)
- Houve fator externo? (timing com evento civico, compartilhamento por influencer, etc)

**Se performance ABAIXO do projetado:**
- Qual dimensao com nota mais baixa provavelmente limitou?
- O hook converteu? (comparar taxa de conclusao slide 1->2 ou taxa de conclusao do reel)
- O CTA converteu? (comparar saves e shares vs likes)
- O timing foi adequado? (dia da semana, horario, competicao no feed)

### 3. Identificar Padroes Cross-Run

Se existirem post-mortems anteriores, compare:
- Temas que consistentemente performam acima/abaixo
- Formatos (carrossel vs reel) que performam melhor para cada tipo de pauta
- Horarios/dias que correlacionam com maior ER
- Dimensoes que consistentemente predizem performance

### 4. Gerar Recomendacoes Acionaveis

Cada recomendacao deve ser:
- Especifica (nao "melhore o hook" mas "hooks com numero especifico tiveram +X% ER")
- Baseada em dados (citar o delta ou padrao que sustenta a recomendacao)
- Direcionada a um agente especifico (Igor, Rafa, Carlos, Bia, etc)

## Formato de Output

```markdown
# Post-Mortem -- {titulo_pauta}

**Run ID:** {run_id}
**Publicado em:** {data}
**Analisado em:** {data} (7 dias pos-publicacao)

## Resumo Executivo

| Peca | ER Projetado | ER Real | Delta | Status |
|---|---|---|---|---|
| Carrossel | {X}%-{Y}% | {Z}% | {+/-N}pp | Acima/Alinhado/Abaixo |
| Reel | {X}%-{Y}% | {Z}% | {+/-N}pp | Acima/Alinhado/Abaixo |

## Analise por Dimensao

| Dimensao | Score Curadoria | Impacto Estimado na Performance | Evidencia |
|---|---|---|---|
| Gancho | {N}/10 | Alto/Medio/Baixo | {evidencia especifica} |
| Compartilhabilidade | {N}/10 | Alto/Medio/Baixo | {shares reais vs projecao} |
| ... | ... | ... | ... |

## O Que Funcionou

1. {ponto forte com evidencia numerica}
2. {ponto forte com evidencia numerica}

## O Que Nao Funcionou

1. {problema com evidencia numerica e causa provavel}
2. {problema com evidencia numerica e causa provavel}

## Fatores Externos

{timing, eventos, compartilhamento por terceiros, etc}

## Recomendacoes para Proximas Runs

| # | Recomendacao | Agente Alvo | Evidencia | Impacto Esperado |
|---|---|---|---|---|
| 1 | {recomendacao especifica} | {agente} | {dado} | {projecao} |
| 2 | {recomendacao especifica} | {agente} | {dado} | {projecao} |

## Benchmark Update

{Se ER > 10% ou alcance > 100k: recomendar adicao a tabela de benchmarks}
{Se nao: "Post nao atingiu threshold para benchmark (ER {X}%, alcance {Y})"}
```

## Veto Conditions

- VETO se post-mortem nao incluir delta projecao vs realidade
- VETO se recomendacoes nao forem direcionadas a agentes especificos
- VETO se analise usar metricas de menos de 7 dias (exceto se explicitamente solicitado)

## Quality Criteria

- Delta calculado com precisao (projecao do scorecard vs metricas reais 7d)
- Atribuicao por dimensao baseada em evidencia, nao intuicao
- Recomendacoes acionaveis e direcionadas a agentes especificos
- Padroes cross-run identificados quando post-mortems anteriores existem
