---
name: update-benchmarks
description: Atualiza quality-criteria.md com novos benchmarks quando post ultrapassa threshold (ER > 10% ou alcance > 100k).
---

# Task: Atualizar Benchmarks

## Input

- Post-mortem: `squads/ubatuba-reage/output/{run_id}/v{n}/post-mortem.md`
- Benchmarks atuais: `squads/ubatuba-reage/pipeline/data/quality-criteria.md`

## Processo

### 1. Verificar Threshold

O post so vira benchmark se atingir pelo menos UM dos criterios:
- ER >= 10% (metricas 7d consolidadas)
- Alcance >= 100.000

Se nenhum criterio atendido: nao atualizar. Registrar no post-mortem.

### 2. Formatar Nova Entrada

```
| {titulo_pauta} | {tipo} | {ER}% | {alcance} | {licao em 1 frase} |
```

A licao deve ser acionavel: "Denuncia com nome + documento + numero = alta conversao", nao "post performou bem".

### 3. Atualizar quality-criteria.md

Adicione a nova linha na tabela de benchmarks do arquivo, mantendo a ordem por ER (maior primeiro).

Se a tabela ultrapassar 8 entradas, remova a de menor ER para manter a tabela concisa.

### 4. Atualizar Metas se Necessario

Se o novo post alterar a media de ER dos benchmarks:
- Recalcule a meta ideal (media dos top 3 benchmarks)
- Atualize se houver mudanca significativa (> 1pp)

## Formato de Output

Edicao direta no arquivo `quality-criteria.md` + confirmacao:

```markdown
# Benchmark Update -- {titulo_pauta}

**Acao:** {Adicionado / Nao qualificado}
**ER:** {X}%
**Alcance:** {N}
**Licao:** {frase}
**Meta ideal atualizada:** {Sim: X% -> Y% / Nao: mantida em X%}
```

## Veto Conditions

- VETO se adicionar post com ER < 10% E alcance < 100k
- VETO se remover benchmark historico sem substituir por um melhor
- VETO se licao for generica ("post performou bem")

## Quality Criteria

- Threshold verificado antes de qualquer edicao
- Licao e acionavel e especifica
- Tabela ordenada por ER decrescente
- Meta ideal recalculada se necessario
