---
name: diagnose-editorial
description: Avalia conteudo nas dimensoes Gancho, Narrativa, Ritmo e Clareza com nota 0-10 e propoe reescrita especifica dos blocos fracos.
---

# Task: Diagnostico Editorial

## Input

- Carrossel aprovado: `squads/ubatuba-reage/output/{run_id}/v{n}/instagram-feed-draft.md`
- Roteiro Reel: `squads/ubatuba-reage/output/{run_id}/v{n}/reels-script-draft.md`
- Rubrica: `squads/ubatuba-reage/pipeline/data/curadoria-criterios.md`
- Noticia base: `squads/ubatuba-reage/pipeline/data/selected-news.md`

## Processo

1. Leia a rubrica completa de 10 dimensoes.
2. Avalie CADA peca (carrossel + reel) nas suas 4 dimensoes prioritarias:

### Gancho (peso 15%)
- O slide 1 / hook do reel para o scroll sozinho?
- Funciona como thumbnail autonomo a 200px?
- Numero ou fato concreto na abertura?

### Narrativa (peso 10%)
- Arco SCQA completo? (Situacao -> Complicacao -> Questao -> Acao)
- Cada slide conecta ao proximo?
- O slide 9 cumpre a promessa do slide 1?

### Ritmo (peso 8%)
- Alternancia cromatica correta?
- Nenhum slide acima de 80 palavras?
- Reel: cortes visuais a cada 3-5s?

### Clareza (peso 10%)
- Morador sem formacao entende em 30s?
- Termos tecnicos traduzidos? (ex: "FINISA" explicado, "impacto orcamentario" traduzido)
- Linguagem cotidiana de Ubatuba?

3. Para cada dimensao, forneca:
   - Nota 0-10 com justificativa
   - Citacao de trecho exato (slide X, linha Y)
   - Proposta de reescrita especifica se nota < 8

## Formato de Output

```markdown
# Diagnostico Editorial -- Carlos Curador

## Carrossel

### Gancho -- [X]/10
**Diagnostico:** [2-3 frases]
**Trecho:** Slide [N]: "[citacao exata]"
**Para chegar a 10:** [sugestao especifica com reescrita]

### Narrativa -- [X]/10
[mesmo formato]

### Ritmo -- [X]/10
[mesmo formato]

### Clareza -- [X]/10
[mesmo formato]

## Reel

[mesmo formato para as 4 dimensoes]

## Proposta de Reescrita

[Apenas os blocos que precisam mudar, com localizacao exata e texto alternativo]

## Impacto Estimado

[Quais dimensoes sobem e quantos pontos]
```

## Veto Conditions

- VETO se feedback nao citar trecho especifico com localizacao
- VETO se propor reescrita que degrade dimensao >= 8

## Quality Criteria

- Cada nota tem justificativa com citacao
- Propostas de reescrita sao concretas (texto pronto, nao direcao vaga)
- Pontos fortes reconhecidos mesmo em notas baixas
