# Task: rank-stories

## Purpose

Apply the Filtro Reage to all raw candidates from `find-news`, cross-reference claims, and produce a final ranked list of 3–5 pautas ready for content production.

---

## Input

`candidates.yaml` — raw candidate list produced by the `find-news` task.

If `candidates.yaml` is absent or contains fewer than 3 items, halt and return an error: `"Candidate list insufficient for ranking. Rerun find-news task."`

---

## Process

1. **Read all candidates** from `candidates.yaml`. Log the total count and the research cycle metadata before scoring.

2. **Apply Filtro Reage to each candidate**:

   - **Impacto (1–5)**: How directly and broadly does this story affect Ubatuba residents or tourists?
     - 5 = Affects basic services (water, roads, sanitation) for thousands of residents or imminent financial harm to the public
     - 3 = Affects a specific neighborhood or a significant group (e.g., beachfront vendors, school families)
     - 1 = Affects a narrow group or is primarily symbolic with no immediate material consequence

   - **Urgência (1–5)**: Is there a deadline, vote, or pressure window within 7 days of the research date?
     - 5 = Hard deadline within 48 hours (Câmara vote tomorrow, service interruption today)
     - 3 = Actionable window within 7 days (public consultation open, council vote scheduled this week)
     - 1 = No active deadline; story is relevant but not time-sensitive

   - **Ângulo**: Identify the most impactful framing for @ubatubareage's content team. Choose one or more:
     - `denúncia` — exposes wrongdoing or negligence with documented evidence
     - `educativo` — explains a civic process or right that residents may not know
     - `memória` — contrasts a past promise with current reality ("prometeram X, entregaram Y")
     - `urgência` — mobilizes action before a deadline (vote, consultation, deadline)

3. **Cross-reference claims**: for any candidate with `confidence: Baixa`, search for a second source before including it in the final ranked list. If no second source is found, the candidate may only appear in the ranked list at position 5 and must retain the `Baixa` label with an explicit warning.

4. **Calculate combined score**: `score = Impacto + Urgência`. In case of ties, the candidate with the higher Urgência score ranks higher (time-sensitive stories are prioritized).

5. **Select top 3–5 candidates** by score. Compose the final output for each.

---

## Output Format

Markdown file saved as `news-ranking.md`:

```
# News Ranking — [topic] — [DD/MM/AAAA]

## Pauta #[N] — Score [X]/10

**Título:** [plain-language title in Portuguese]
**Impacto:** [1–5] | **Urgência:** [1–5]
**Ângulo:** [denúncia | educativo | memória | urgência]
**Urgência Flag:** [SIM — deadline: DD/MM/AAAA | NÃO]

**Resumo:** [Two sentences. First: what happened, with the key fact. Second: why it matters to Ubatuba residents or tourists specifically.]

**Dado-chave:** [Single most important verifiable data point — contract number, BRL value, date, vote count, etc.]

**Fontes:**
- [Source name]: [URL]
- [Source name]: [URL]

**Confiança:** [Alta | Média | Baixa]
[If Baixa: "ATENÇÃO: confirmação de segunda fonte não localizada. Verificação adicional necessária antes de produção."]

---
```

---

## Output Example

```markdown
# News Ranking — contratos e obras públicas — 23/03/2026

## Pauta #1 — Score 9/10

**Título:** Câmara vota amanhã projeto que isenta hotéis de taxa de limpeza — moradores pagam a conta
**Impacto:** 4 | **Urgência:** 5
**Ângulo:** denúncia, urgência
**Urgência Flag:** SIM — deadline: 26/03/2026

**Resumo:** O PL 008/2026, pautado para votação na sessão plenária de quinta-feira (26/03), isenta estabelecimentos hoteleiros da Taxa de Limpeza e Varrição de Praias (TLVP), transferindo o custo do serviço ao contribuinte comum. A medida beneficia diretamente o setor mais lucrativo da cidade durante a alta temporada, enquanto reduz a receita municipal destinada à limpeza das praias públicas.

**Dado-chave:** PL 008/2026 — votação marcada para 26/03/2026 às 14h; isenção estimada em R$ 1,2 milhão/ano segundo nota da Secretaria de Finanças anexa ao projeto.

**Fontes:**
- Câmara Municipal de Ubatuba (pauta oficial): https://www.camaraubatuba.sp.gov.br/sessoesplenarias/2026-03-26
- Portal da Transparência — Receita TLVP: https://transparencia.ubatuba.sp.gov.br/receitas/tlvp

**Confiança:** Alta

---

## Pauta #2 — Score 8/10

**Título:** Empresa com 3 meses de existência recebe R$ 480 mil da prefeitura sem licitação
**Impacto:** 5 | **Urgência:** 3
**Ângulo:** denúncia
**Urgência Flag:** NÃO

**Resumo:** A Prefeitura de Ubatuba publicou no Diário Oficial de 18/03/2026 a Dispensa de Licitação n° 014/2026, contratando diretamente uma empresa de pavimentação asfáltica por R$ 480.000,00. O CNPJ da contratada foi aberto em dezembro de 2025, sem histórico de obras executadas ou capacidade técnica demonstrada nos documentos públicos.

**Dado-chave:** Dispensa de Licitação n° 014/2026 — R$ 480.000,00 — empresa contratada: CNPJ 57.XXX.XXX/0001-XX, abertura 12/2025.

**Fontes:**
- Diário Oficial de Ubatuba (18/03/2026): https://diariooficial.ubatuba.sp.gov.br/edicoes/2026-03-18
- Portal da Transparência — Contratos: https://transparencia.ubatuba.sp.gov.br/contratos/014-2026

**Confiança:** Alta

---

## Pauta #3 — Score 7/10

**Título:** SABESP cortou água em 12 bairros por 48h com apenas 6 horas de aviso — e fez de novo
**Impacto:** 5 | **Urgência:** 2
**Ângulo:** denúncia, memória
**Urgência Flag:** NÃO

**Resumo:** A SABESP realizou interrupção programada de 48 horas no fornecimento de água para 12 bairros de Ubatuba em 20/03/2026, comunicando o corte apenas 6 horas antes — em desacordo com o prazo mínimo de 48h exigido pelo contrato de concessão. É o terceiro episódio sem aviso adequado em 60 dias.

**Dado-chave:** Interrupção de 20/03/2026 — bairros afetados: Itaguá, Praia Grande, Perequê-Açu (entre outros); prazo legal de notificação: 48h; notificação real: 6h antes.

**Fontes:**
- SABESP — Comunicado oficial: https://site.sabesp.com.br/site/interna/Default.aspx?secaoId=65
- G1 Vale do Paraíba: https://g1.globo.com/sp/vale-do-paraiba-regiao/noticia/2026/03/20/sabesp-corta-agua.ghtml

**Confiança:** Alta

---

## Pauta #4 — Score 6/10

**Título:** SP-55 fechada sem prazo: único acesso terrestre ao litoral norte bloqueado na alta temporada
**Impacto:** 4 | **Urgência:** 2
**Ângulo:** urgência, denúncia
**Urgência Flag:** NÃO

**Resumo:** O DER-SP interditou uma faixa da SP-55 no km 53, entre Ubatuba e Caraguatatuba, para obras sem previsão de conclusão desde 19/03/2026. A rodovia é o único acesso terrestre ao litoral norte para quem vem da Grande São Paulo, e a interdição sem prazo aumenta o risco de colapso viário durante os feriados de abril.

**Dado-chave:** Interdição km 53 SP-55 — início 19/03/2026 — sem data de conclusão publicada; próximo feriado prolongado: Páscoa (18–21/04/2026).

**Fontes:**
- DER-SP — Aviso de interdição: https://www.der.sp.gov.br/Website/Paginas/Noticia.aspx?id=4821
- G1 Vale do Paraíba: https://g1.globo.com/sp/vale-do-paraiba-regiao/noticia/2026/03/20/der-sp-sp55.ghtml

**Confiança:** Alta

---

## Pauta #5 — Score 4/10

**Título:** Buraco de 1 metro na Av. Leovegildo completa 45 dias sem reparo e moradores do Tenório cobram prefeitura
**Impacto:** 3 | **Urgência:** 1
**Ângulo:** denúncia, memória
**Urgência Flag:** NÃO

**Confiança:** Baixa
ATENÇÃO: confirmação de segunda fonte não localizada. Verificação adicional necessária antes de produção.

**Resumo:** Moradores do Tenório relatam nas redes sociais que um buraco de aproximadamente 1 metro de diâmetro na Avenida Leovegildo Dias Vieira completa 45 dias sem reparo pela prefeitura. Nenhuma ordem de serviço foi localizada no Portal da Transparência para o endereço mencionado.

**Dado-chave:** Post no Facebook/Ubatuba Denúncias com 1.200 compartilhamentos — data do relato original: 07/03/2026 — nenhuma OS localizada no Portal da Transparência.

**Fontes:**
- Facebook/Ubatuba Denúncias: https://www.facebook.com/groups/ubatubadenuncia/posts/123456789
```

---

## Veto Conditions

- **Veto if score is 3 or below**: any candidate with a combined Impacto + Urgência score of 3 or less must be excluded from the final ranking, even if the total list would fall below 3 items. In that case, halt and return: `"Insufficient high-score candidates. Rerun find-news with broader scope."`
- **Veto if no direct Ubatuba relevance**: any candidate that affects São Paulo state broadly but cannot be confirmed to impact Ubatuba specifically must be vetoed, regardless of score.

---

## Quality Criteria

- The ranked list contains no fewer than 3 and no more than 5 pautas; if fewer than 3 pass the score threshold, the task fails and must not produce a partial output.
- Every ranked pauta includes at least one source URL from Pillar A or Pillar D (official or transparency sources); a ranking composed entirely of news articles and community signals is not acceptable.
- Urgência flags are accurate: `SIM` is only applied when a concrete, named deadline (vote date, consultation closing date, service interruption date) falls within 7 days of the `generated_at` date in `candidates.yaml`.
