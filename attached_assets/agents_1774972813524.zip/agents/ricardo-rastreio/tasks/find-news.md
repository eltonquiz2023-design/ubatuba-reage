# Task: find-news

## Purpose

Scan all 4 source pillars for candidate pautas relevant to Ubatuba's civic landscape and collect a raw list of 10–20 items ready for ranking.

---

## Input

`research-focus.md` — user-defined file containing:
- **topic**: the specific theme or area of concern for this research cycle (e.g., "obras de saneamento", "licitações da prefeitura", "Câmara Municipal votações")
- **time_range**: start and end dates to constrain the search (e.g., "01/03/2026 a 23/03/2026")

If `research-focus.md` is absent, use the current week as the time range and scan all pillars without a topic filter.

---

## Process

1. **Read `research-focus.md`** to extract `topic` and `time_range`. Log both values before proceeding.

2. **Scan Pillar A — Official Sources** using `web_search` and `web_fetch`:
   - Diário Oficial de Ubatuba: search for publications within `time_range`
   - Portal da Transparência da Prefeitura de Ubatuba: look for new contracts, licitações, and dispensas de licitação
   - EMDURB (Empresa Municipal de Desenvolvimento Urbano): check for contracts or service notices
   - Câmara Municipal de Ubatuba: check for scheduled sessions, pautas votadas, and projetos de lei in progress

3. **Scan Pillar B — Local News** using `web_search`:
   - G1 Vale do Paraíba (filter results to Ubatuba section)
   - Tamoios News
   - Portal R7 / TV Vanguarda (Ubatuba mentions)
   - Search queries: `"Ubatuba" + topic + time_range`, `"Prefeitura de Ubatuba" + time_range`

4. **Scan Pillar C — Community Signals** using `web_search`:
   - Facebook groups: "Ubatuba Denúncias", "Ubatuba Reclamações", "Ubatuba SP"
   - X/Twitter keywords: `"Ubatuba"`, `"Prefeitura de Ubatuba"`, `"Praia do Tenório"`, `"Câmara Ubatuba"`
   - Note: community signals are Low confidence by default unless corroborated by Pillar A or B

5. **Scan Pillar D — Specific Transparency Portals** using `web_fetch`:
   - DER-SP: check for road maintenance or concession notices affecting SP-55, SP-171, or Ubatuba access routes
   - SABESP: check for service interruptions, investment announcements, or contract publications affecting Ubatuba's water/sewage supply

6. **Compile candidates**: for each item found, record the fields defined in the output format below. Target 10–20 candidates. Stop at 20 even if more results are available.

---

## Output Format

YAML file saved as `candidates.yaml`:

```yaml
research_cycle:
  topic: "<topic from research-focus.md>"
  time_range: "<time_range from research-focus.md>"
  generated_at: "<DD/MM/AAAA>"

candidates:
  - id: 1
    title: "<plain-language title in Portuguese>"
    pillar: "<A | B | C | D>"
    source_url: "<direct URL>"
    access_date: "<DD/MM/AAAA>"
    publication_date: "<DD/MM/AAAA or 'desconhecida'>"
    key_data_point: "<single most important verifiable fact>"
    confidence: "<Alta | Média | Baixa>"
    confidence_reason: "<one sentence explaining the confidence level>"
```

---

## Output Example

```yaml
research_cycle:
  topic: "contratos e obras públicas"
  time_range: "01/03/2026 a 23/03/2026"
  generated_at: "23/03/2026"

candidates:
  - id: 1
    title: "Prefeitura contrata empresa de fachada para pavimentação sem licitação — R$ 480 mil"
    pillar: A
    source_url: "https://diariooficial.ubatuba.sp.gov.br/edicoes/2026-03-18"
    access_date: "23/03/2026"
    publication_date: "18/03/2026"
    key_data_point: "Dispensa de licitação n° 014/2026 para serviços de pavimentação asfáltica, valor R$ 480.000,00, empresa com CNPJ aberto há 3 meses."
    confidence: Alta
    confidence_reason: "Documento oficial publicado no Diário Oficial de Ubatuba, número de dispensa verificado."

  - id: 2
    title: "SABESP anuncia interrupção de água no Itaguá e Praia Grande por 48h sem aviso prévio"
    pillar: D
    source_url: "https://site.sabesp.com.br/site/interna/Default.aspx?secaoId=65"
    access_date: "23/03/2026"
    publication_date: "20/03/2026"
    key_data_point: "Interrupção programada de 48h afeta 12 bairros de Ubatuba; comunicação publicada apenas 6h antes do corte."
    confidence: Alta
    confidence_reason: "Comunicado oficial SABESP acessado diretamente; confirmado por nota no G1 Vale do Paraíba."

  - id: 3
    title: "Câmara Municipal vota na quinta-feira projeto que isenta hotéis de taxa de limpeza pública"
    pillar: A
    source_url: "https://www.camaraUbatuba.sp.gov.br/sessoesplenarias/2026-03-26"
    access_date: "23/03/2026"
    publication_date: "22/03/2026"
    key_data_point: "PL 008/2026 isenta estabelecimentos com CNAE hoteleiro da TLVP; votação marcada para 26/03/2026."
    confidence: Alta
    confidence_reason: "Pauta da sessão publicada no site oficial da Câmara Municipal de Ubatuba."

  - id: 4
    title: "Moradores do Tenório relatam buraco na Av. Leovegildo Dias Vieira há 45 dias sem reparo"
    pillar: C
    source_url: "https://www.facebook.com/groups/ubatubadenuncia/posts/123456789"
    access_date: "23/03/2026"
    publication_date: "21/03/2026"
    key_data_point: "Post com 340 comentários e 1.200 compartilhamentos; foto mostra buraco de ~1m de diâmetro em via principal."
    confidence: Baixa
    confidence_reason: "Fonte única; nenhuma confirmação no Diário Oficial ou imprensa local até o momento."

  - id: 5
    title: "DER-SP interdita faixa da SP-55 entre Ubatuba e Caraguatatuba para obras sem prazo definido"
    pillar: D
    source_url: "https://www.der.sp.gov.br/Website/Paginas/Noticia.aspx?id=4821"
    access_date: "23/03/2026"
    publication_date: "19/03/2026"
    key_data_point: "Interdição parcial na altura do km 53 sem data de conclusão; afeta único acesso terrestre ao litoral norte em temporada."
    confidence: Alta
    confidence_reason: "Aviso oficial DER-SP acessado diretamente; confirmado por G1 Vale do Paraíba em 20/03/2026."
```

---

## Veto Conditions

- **Veto if outside time range**: any item whose `publication_date` falls outside the `time_range` defined in `research-focus.md` must be excluded from the candidate list, unless it is an ongoing situation with active developments within the range.
- **Veto if no source URL**: any item without a verifiable, directly accessible URL must be excluded. Do not include items based on recalled knowledge or general awareness — every candidate must have a live source link recorded at the time of access.

---

## Quality Criteria

- The candidate list contains between 10 and 20 items; lists below 10 indicate insufficient scan coverage and must trigger a second pass.
- Every candidate in Pillar C (community signals) is marked `Baixa` confidence unless a corroborating source from Pillar A or B was found during the same research cycle.
- At least 3 candidates come from Pillar A (official sources); a list with no official-source candidates is incomplete regardless of total count.
