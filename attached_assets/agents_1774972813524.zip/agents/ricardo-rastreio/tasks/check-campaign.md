---
name: check-campaign
description: Verifica se a pauta selecionada pertence a uma campanha existente e sugere posicionamento no ciclo de campanha (Exposicao/Pressao/Responsabilizacao/Memoria).
---

# Task: Verificar Campanha

## Input

- Noticia selecionada: `squads/ubatuba-reage/pipeline/data/selected-news.md`
- Campanhas ativas: `squads/ubatuba-reage/pipeline/data/campaigns.md`
- Framework de dominio: `squads/ubatuba-reage/pipeline/data/domain-framework.md` (secao Ciclo de Campanha)

## Processo

### 1. Identificar Tema e Entidades

Da noticia selecionada, extraia:
- Tema central (ex: "emprestimo de R$ 70 milhoes", "transporte escolar", "obra do Tenorio")
- Pessoas citadas (nomes de vereadores, prefeito, secretarios)
- Instituicoes (Camara, Prefeitura, SABESP, DER)
- Numero de contrato/PL/processo (se houver)

### 2. Buscar Campanha Existente

Leia `campaigns.md` e verifique se alguma campanha ativa compartilha:
- O mesmo tema central
- As mesmas pessoas/instituicoes
- O mesmo contrato/PL/processo

### 3. Se Campanha Existente

Determine a fase atual no ciclo:

| Fase | Duracao | Indicador |
|---|---|---|
| EXPOSICAO | Semana 1 | Primeiro post sobre o tema |
| PRESSAO | Semana 2-3 | Posts de follow-up, "sem resposta ate agora" |
| RESPONSABILIZACAO | Semana 4 | Resposta (ou ausencia) dos responsaveis |
| MEMORIA | Mes seguinte | "X dias sem resposta", linha do tempo |

Sugira:
- Tom ideal para esta fase (ver tone-of-voice.md)
- Angulo recomendado (continuidade, revelacao nova, cobranca)
- Referencia ao(s) post(s) anterior(es) da campanha

### 4. Se Campanha Nova

Crie uma nova entrada em `campaigns.md` com:
- ID unico
- Tema
- Entidades envolvidas
- Data de inicio
- Fase: EXPOSICAO
- Posts planejados (4 semanas)

## Formato de Output

```markdown
# Verificacao de Campanha -- {titulo_pauta}

## Resultado: {CAMPANHA EXISTENTE / CAMPANHA NOVA}

### Se Campanha Existente:

**Campanha:** {nome da campanha}
**ID:** {campaign_id}
**Fase atual:** {EXPOSICAO / PRESSAO / RESPONSABILIZACAO / MEMORIA}
**Posts anteriores:** {lista com run_id e data}
**Tom recomendado:** {tom do tone-of-voice.md}
**Angulo sugerido:** {continuidade / revelacao nova / cobranca / memoria}
**Conexao narrativa:** {como este post conecta ao anterior}

### Se Campanha Nova:

**Nova campanha criada:**
- ID: {campaign_id}
- Tema: {tema}
- Entidades: {lista}
- Fase: EXPOSICAO
- Plano de 4 semanas:
  - Semana 1: {EXPOSICAO -- este post}
  - Semana 2-3: {PRESSAO -- angulo sugerido}
  - Semana 4: {RESPONSABILIZACAO -- angulo sugerido}
  - Mes seguinte: {MEMORIA -- angulo sugerido}
```

## Veto Conditions

- VETO se ignorar campanhas existentes com o mesmo tema/entidade
- VETO se sugerir fase que nao corresponde a timeline real

## Quality Criteria

- Busca em campaigns.md feita por tema, pessoa E instituicao (nao apenas tema)
- Fase corretamente identificada pela timeline
- Tom e angulo alinhados com a fase do ciclo de campanha
