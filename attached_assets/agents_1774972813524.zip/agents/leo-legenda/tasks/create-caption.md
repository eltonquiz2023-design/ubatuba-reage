---
name: create-caption
description: Gera legendas otimizadas para carrossel e reel com hook de 125 chars, frase pronta para cidadao e hashtags separadas.
---

# Task: Criar Legenda/Caption

## Input

- Carrossel aprovado: `squads/ubatuba-reage/output/{run_id}/v{n}/instagram-feed-draft.md`
- Roteiro Reel: `squads/ubatuba-reage/output/{run_id}/v{n}/reels-script-draft.md`
- Angulo selecionado: `squads/ubatuba-reage/pipeline/data/selected-angle.md`
- Tom de voz: `squads/ubatuba-reage/pipeline/data/tone-of-voice.md`
- Noticia base: `squads/ubatuba-reage/pipeline/data/selected-news.md`

## Processo

### 1. Analisar o Conteudo Aprovado

Leia o carrossel e o reel completos. Identifique:
- O dado mais impactante (para o hook dos 125 chars)
- Informacao complementar que NAO esta nos slides/reel (para o corpo da legenda)
- O CTA principal do conteudo (para alinhar o CTA da legenda)
- Fonte primaria citada (para a frase pronta do cidadao)

### 2. Gerar Legenda do Carrossel

**Bloco 1 -- Hook (max 125 caracteres)**
- Reforcar o hook do slide 1 sem repeti-lo palavra por palavra
- Conter o dado mais impactante em forma condensada
- Criar curiosidade que obriga o tap no "mais"
- Testar: leia so esses 125 chars. Voce tocaria em "mais"?

**Bloco 2 -- Contexto (2-3 frases)**
- Informacao que complementa os slides (bastidores, timeline, contexto politico)
- Nunca repetir o que ja esta nos slides
- Tom mais pessoal que os slides: "nos descobrimos", "a gente foi la ver"

**Bloco 3 -- Frase Pronta (obrigatoria em denuncias)**
- Entre aspas, pronta para copiar e colar
- Direcionada ao orgao competente (vereador, ouvidoria, MP)
- Inclui referencia ao documento (numero, data)
- Ex: "Exmo. Vereador, solicito esclarecimentos sobre o contrato n [X] publicado no Diario Oficial de [data]. Como eleitor de Ubatuba, exijo transparencia."

**Bloco 4 -- CTA**
- Um CTA primario (acao + beneficio)
- Um CTA de compartilhamento (envio via DM/WhatsApp)
- Pergunta de engajamento para comentarios

### 3. Gerar Legenda do Reel

Mesma estrutura em 4 blocos, adaptada:
- Hook mais curto (reel ja tem hook visual forte)
- Contexto pode revelar bastidores da producao do reel
- Frase pronta identica a do carrossel (consistencia)
- CTA pode focar em "salva pra consultar depois"

### 4. Gerar Hashtags (Primeiro Comentario)

- 5-15 hashtags total
- Mix: 3-5 nicho (#ubatubareage #fiscalizacaoubatuba #camaraubatuba)
- Mix: 3-5 medio porte (#transparenciapublica #dinheiropublico #ativismodigital)
- Mix: 2-3 amplo (#ubatuba #litoralnorte #cidadania)
- NUNCA usar hashtags na legenda. Sempre no primeiro comentario

## Formato de Output

```markdown
# Legendas -- {titulo_pauta}

## Legenda do Carrossel

{legenda completa com os 4 blocos}

**Caracteres do hook:** {N}/125

## Legenda do Reel

{legenda completa com os 4 blocos}

**Caracteres do hook:** {N}/125

## Hashtags (Primeiro Comentario)

### Carrossel
{hashtags}

### Reel
{hashtags}

## Frase Pronta para o Cidadao

"{frase completa entre aspas}"

**Destinatario sugerido:** {orgao/pessoa}
**Canal:** {e-mail da ouvidoria / WhatsApp do gabinete / etc}
```

## Veto Conditions

- VETO se hook tiver mais de 125 caracteres
- VETO se legenda repetir copy dos slides/reel
- VETO se denuncia sem frase pronta para o cidadao
- VETO se hashtags estiverem na legenda em vez de comentario separado

## Quality Criteria

- Hook dos primeiros 125 chars funciona standalone (geraria tap)
- Legenda complementa os slides, nao repete
- Frase pronta e realista (alguem de fato enviaria)
- Tom alinhado com o tom do conteudo
- Hashtags no formato correto (primeiro comentario, 5-15 tags)
