---
name: prepare-engagement-plan
description: Gera plano de engajamento pre-publicacao com comentarios esperados, templates de resposta e flags de crise potenciais.
---

# Task: Preparar Plano de Engajamento

## Input

- Carrossel aprovado: `squads/ubatuba-reage/output/{run_id}/v{n}/instagram-feed-draft.md`
- Roteiro Reel: `squads/ubatuba-reage/output/{run_id}/v{n}/reels-script-draft.md`
- Legendas: `squads/ubatuba-reage/output/{run_id}/v{n}/captions.md`
- Noticia base: `squads/ubatuba-reage/pipeline/data/selected-news.md`

## Processo

### 1. Mapear Pontos Sensiveis

Leia o conteudo e identifique:
- Pessoas nomeadas (vereadores, prefeito, secretarios)
- Numeros que podem ser questionados
- Afirmacoes que podem gerar reacao defensiva dos citados
- Temas polemicos que podem dividir a comunidade

### 2. Prever Tipos de Comentario

Para cada ponto sensivel, preveja os tipos de comentario:

**Apoio:** "Parabens pelo trabalho", "Isso tinha que ser divulgado"
**Duvida factual:** "Mas esse numero ta certo?", "Onde voce viu isso?"
**Critica ao movimento:** "Isso e tendencioso", "Voces so criticam"
**Defesa do citado:** "O vereador X nao e assim", "Voces nao sabem a historia completa"
**Pedido de acao:** "E o que a gente faz?", "Tem como denunciar?"
**Compartilhamento de experiencia:** "No meu bairro tambem...", "Ja passei por isso"

### 3. Criar Templates de Resposta

Para cada tipo de comentario, crie um template adaptavel:

**Template nao e copy-paste.** E uma estrutura:
- Abertura (reconhecer o comentario)
- Dado factual (fonte + link quando aplicavel)
- Degrau na escada de engajamento (proxima acao sugerida)

### 4. Identificar Flags de Crise

Cenarios que exigem escalacao imediata:
- Comentario que identifica erro factual real
- Ameaca legal ("vou processar", "isso e calunia")
- Pessoa citada no post respondendo diretamente
- Desinformacao organizada nos replies (multiplas contas repetindo a mesma narrativa)

## Formato de Output

```markdown
# Plano de Engajamento -- {titulo_pauta}

## Pontos Sensiveis

| # | Ponto | Slide/Beat | Reacao Esperada |
|---|---|---|---|
| 1 | {ponto} | Slide {N} | {tipo de reacao} |

## Templates de Resposta

### Apoio
**Template:** Obrigado, {nome}! {dado complementar}. Compartilha com alguem de Ubatuba que precisa saber disso.

### Duvida Factual
**Template:** Boa pergunta, {nome}. O dado vem de {fonte} publicado em {data}. Voce pode verificar direto em {link}. Se encontrar algo diferente, nos manda!

### Critica ao Movimento
**Template:** {nome}, todos os dados deste post sao de fontes publicas: {lista}. Convidamos voce a verificar. Se encontrar algum erro, queremos corrigir.

### Defesa do Citado
**Template:** {nome}, o post apresenta dados de {fonte publica}. Se o {cargo} quiser se manifestar, publicamos a resposta na integra. Transparencia e para todos os lados.

### Pedido de Acao
**Template:** {nome}, voce pode: (1) {acao 1}, (2) {acao 2}, (3) {acao 3}. O link pro documento esta na bio.

### Experiencia Pessoal
**Template:** {nome}, obrigado por compartilhar. Seu relato e importante. Voce autoriza a gente usar no proximo post sobre o tema? (DM se preferir)

## Flags de Crise

| # | Cenario | Indicador | Acao |
|---|---|---|---|
| 1 | Erro factual identificado | Comentario com fonte que contradiz o post | ESCALAR IMEDIATO ao usuario |
| 2 | Ameaca legal | "Processo", "advogado", "calunia" | ESCALAR em < 15min |
| 3 | Pessoa citada responde | Conta verificada ou oficial | ESCALAR para decisao de como publicar resposta |
| 4 | Desinformacao organizada | 3+ contas com narrativa identica | ESCALAR + documentar screenshots |

## Checklist Golden Hour

- [ ] Responder primeiros 5 comentarios em < 15 min
- [ ] Fixar comentario com frase pronta para cidadao
- [ ] Monitorar replies a cada 10 min na primeira hora
- [ ] Verificar se algum flag de crise foi acionado
```

## Veto Conditions

- VETO se plano nao mapear pessoas nomeadas no conteudo
- VETO se templates nao incluirem dado factual
- VETO se nao houver secao de flags de crise

## Quality Criteria

- Todos os pontos sensiveis do conteudo mapeados
- Templates adaptaveis (nao copy-paste) para cada tipo de comentario
- Cada template move o seguidor um degrau na escada de engajamento
- Flags de crise com indicadores claros e acao definida
