---
name: escalate-crisis
description: Identifica e escala situacoes criticas (erro factual, ameaca legal, desinformacao) ao usuario com relatorio estruturado.
---

# Task: Escalar Crise

## Input

- Comentario(s) critico(s): fornecidos pelo usuario
- Plano de engajamento: `squads/ubatuba-reage/output/{run_id}/v{n}/engagement-plan.md`
- Conteudo publicado: `squads/ubatuba-reage/output/{run_id}/v{n}/instagram-feed-draft.md`
- Noticia base: `squads/ubatuba-reage/pipeline/data/selected-news.md`

## Processo

### 1. Classificar a Crise

| Nivel | Tipo | Tempo de Resposta |
|---|---|---|
| CRITICO | Erro factual confirmado no post | Imediato (corrigir ou remover) |
| ALTO | Ameaca legal de pessoa citada | < 1h (avaliar amparo documental) |
| MEDIO | Pessoa publica citada responde | < 2h (preparar publicacao da resposta) |
| BAIXO | Desinformacao organizada | < 4h (documentar e monitorar) |

### 2. Verificar a Alegacao

Se o comentario alega erro factual:
- Confronte a afirmacao do post com a fonte primaria (selected-news.md)
- Verifique se o dado esta correto, parcialmente correto, ou incorreto
- Se incorreto: CONFIRMAR CRISE e recomendar acao imediata

### 3. Gerar Relatorio de Escalacao

## Formato de Output

```markdown
# ESCALACAO DE CRISE -- {titulo_pauta}

**Nivel:** {CRITICO / ALTO / MEDIO / BAIXO}
**Tipo:** {erro factual / ameaca legal / resposta de citado / desinformacao}
**Detectado em:** {data e hora}
**Tempo maximo para acao:** {tempo}

## O Que Aconteceu

**Comentario original:** @{usuario}: "{texto}"
**Contexto:** {onde no post o problema esta}

## Verificacao

**Afirmacao do post:** "{trecho exato do slide/reel}"
**Fonte primaria:** {documento, URL}
**Status:** {Correto / Parcialmente incorreto / Incorreto}
**Evidencia:** {o que a verificacao encontrou}

## Opcoes de Acao

### Opcao A: {acao}
**Risco:** {nivel}
**Impacto:** {descricao}

### Opcao B: {acao}
**Risco:** {nivel}
**Impacto:** {descricao}

## Recomendacao

{acao recomendada com justificativa}

## Rascunho de Comunicacao (se aplicavel)

{texto sugerido para nota de correcao, resposta publica, ou errata}
```

## Veto Conditions

- VETO se tentar resolver crise CRITICO ou ALTO sem escalar ao usuario
- VETO se nao verificar a fonte primaria antes de classificar a crise

## Quality Criteria

- Nivel de crise classificado corretamente com tempo de resposta
- Verificacao confronta o post com a fonte primaria
- Opcoes de acao apresentadas com risco e impacto
- Rascunho de comunicacao pronto para uso
