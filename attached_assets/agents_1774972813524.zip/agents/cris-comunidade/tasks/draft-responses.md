---
name: draft-responses
description: Recebe comentarios reais pos-publicacao e gera respostas personalizadas baseadas no plano de engajamento.
---

# Task: Redigir Respostas

## Input

- Plano de engajamento: `squads/ubatuba-reage/output/{run_id}/v{n}/engagement-plan.md`
- Comentarios reais: fornecidos pelo usuario (texto dos comentarios)
- Noticia base: `squads/ubatuba-reage/pipeline/data/selected-news.md`

## Processo

### 1. Classificar Cada Comentario

Para cada comentario recebido, classifique:
- Tipo: apoio / duvida factual / critica / defesa / pedido de acao / experiencia pessoal / troll
- Urgencia: normal / alta (flag de crise)
- Oportunidade: escada de engajamento (qual proximo degrau para esse seguidor)

### 2. Redigir Resposta Personalizada

Baseado no template do plano de engajamento, personalize:
- Use o nome do seguidor
- Referencie o conteudo especifico do comentario (nao resposta generica)
- Inclua dado factual quando aplicavel
- Termine com proximo passo concreto (degrau na escada)

### 3. Escalar se Necessario

Se o comentario acionar um flag de crise:
- NAO redigir resposta
- Marcar como ESCALAR com justificativa
- Sugerir acao ao usuario

## Formato de Output

```markdown
# Respostas -- {titulo_pauta}

## Comentario 1: @{usuario}
**Original:** "{texto do comentario}"
**Tipo:** {classificacao}
**Urgencia:** Normal
**Resposta:**
{resposta personalizada}
**Proximo degrau:** {acao sugerida para esse seguidor}

---

## Comentario 2: @{usuario}
[mesmo formato]

---

## ESCALAR

### @{usuario} -- Flag: {tipo de crise}
**Original:** "{texto}"
**Motivo da escalacao:** {justificativa}
**Acao sugerida:** {recomendacao ao usuario}
```

## Quality Criteria

- Nenhuma resposta e identica a outra
- Respostas incluem dado factual quando o comentario questiona informacao
- Cada resposta tenta mover o seguidor um degrau
- Flags de crise escalados sem resposta autonoma
