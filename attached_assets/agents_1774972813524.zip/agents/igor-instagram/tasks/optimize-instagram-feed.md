# Task: Optimize Instagram Feed

## Purpose
Run a structured optimization pass on `instagram-feed-draft.md` to produce the final, publication-ready carousel.

## Input
- `instagram-feed-draft.md` — complete carousel from `create-instagram-feed.md`

## Output
- `instagram-feed-final.md` — revised carousel + change log

---

## Process

### Step 1 — Copy Stress Test (every slide)
For each slide, apply the three-question stress test:

| Pergunta | Critério de aprovação |
|---|---|
| **Clareza em 3 segundos:** lendo apenas a headline, o morador entende o ponto do slide? | Sim sem precisar do texto de apoio |
| **Redundância:** o texto de apoio repete a headline ou acrescenta informação nova? | Deve acrescentar — nunca repetir |
| **Emoção:** o slide ativa a emoção prevista pelo ângulo selecionado? | Sim de forma específica, não genérica |

Slides que reprovam em qualquer pergunta são reescritos antes de prosseguir.

### Step 2 — Word Count Check
Contar as palavras de headline + texto de apoio em cada slide:

| Slide | Faixa ideal | Ação se fora da faixa |
|---|---|---|
| 1 (Hook) | 15–30 palavras | Acima: corta até o osso. Abaixo: raramente necessário, mas adiciona a implicação se faltou. |
| 2–7 (Corpo) | 40–80 palavras | Acima de 80: divide o slide em dois ou corta o menos essencial. Abaixo de 40: verifica se o dado principal e a fonte estão presentes. |
| 8 (CTA) | 20–40 palavras | Acima: remove tudo que não é ação + benefício + urgência. |

Registrar no change log cada slide ajustado e a contagem antes/depois.

### Step 3 — Source Visibility Audit
Para cada slide que contém dado numérico (valores em R$, porcentagens, datas de pagamento, contagens):

- Confirma que o nome da fonte está visível no próprio slide (não apenas na legenda)
- Verifica se o dado tem o equivalente em escala humana (R$ X = Y) quando o valor supera R$ 50 mil
- Se a fonte está ausente no slide: adiciona rodapé "Fonte: [nome]" antes de prosseguir
- Se o equivalente em escala humana está faltando: calcula e insere no texto de apoio

### Step 4 — Hook Stress Test (Slide 1)
Teste específico para o Slide 1:

**Teste do Polegar:** imaginando que esse slide aparece sozinho no feed do Instagram entre fotos de cachorro e viagem para Búzios — ele para o scroll? Critério: contém um fato inesperado, um número específico, ou uma pergunta que o morador não pode ignorar.

**Teste do WhatsApp:** se esse slide fosse encaminhado sozinho em um grupo de moradores de Ubatuba, alguém clicaria para ver o resto? Critério: o slide levanta uma questão que só o carrossel completo responde.

**Teste da Especificidade:** remova o nome "Ubatuba" do slide. Ele ainda faz sentido? Se sim, reescreve — o hook deve ser insubstituível para este lugar e esta história.

Se o Slide 1 reprovar em qualquer um dos três testes, Igor reescreve e documenta no change log.

### Step 5 — CTA Sharpening (Slide 8)
Verificar o CTA final contra o protocolo:

| Elemento | Presente? | Ação se ausente |
|---|---|---|
| Uma ação específica (verbo imperativo + objeto) | — | Reescreve com verbo claro: "Protocole", "Salva", "Compartilha" |
| Um benefício claro para quem age | — | Adiciona: "para ter o número do contrato na mão", "para pressionar antes da votação" |
| Um elemento de urgência ou prazo | — | Adiciona data da votação, prazo de denúncia, ou urgência narrativa ("antes que arquivem") |
| Apenas uma ação (não três em sequência) | — | Remove todas as ações secundárias. Mantém somente a de maior impacto. |

### Step 6 — Anti-Commodity Check
Teste final antes de gerar `instagram-feed-final.md`:

**Teste da Substituição:** substitua "Ubatuba" por "Campinas" e "Saco da Ribeira" por qualquer outro bairro. O carrossel ainda funciona sem nenhuma outra alteração? Se sim, o conteúdo é genérico — reescreve os slides que passaram nessa troca com elementos intransferíveis: nome do secretário, número do contrato, nome do bairro específico, comparação com referência local (ex: "equivale ao orçamento anual da UBS do Maranduba").

**Teste da Voz:** o tom do carrossel é reconhecível como @ubatubareage ou poderia ser qualquer conta de transparência pública? O estilo Indignação Construtiva deve estar presente — raiva canalizada em ação, não em desespero performático.

---

## Output Format

```
=== FORMAT ===
Versão: Final
Data de otimização: [data]
Número de slides: [8/9/10]
Alterações realizadas: [N]

=== SLIDES ===

[Carrossel completo revisado — mesma estrutura de create-instagram-feed.md]

--- SLIDE 1 — HOOK ---
Headline: [versão final]
Texto de apoio: [versão final]
Direção de imagem: [versão final]
Accent keywords: [versão final]
Fundo: [versão final]

[... slides 2–8 no mesmo formato ...]

=== CAPTION ===
[Legenda completa revisada]

=== HASHTAGS ===
[Lista final de 10 hashtags]

=== CHANGE LOG ===

SLIDE 1
- Antes: "Prefeitura usou dinheiro público de forma irregular"
- Depois: "A Prefeitura de Ubatuba pagou R$ 1,2 milhão por uma obra que nunca saiu do papel"
- Motivo: Reprovar no Teste da Especificidade — versão anterior não continha dado numérico nem localização

SLIDE 3
- Antes: 92 palavras (acima do limite de 80)
- Depois: 71 palavras
- Motivo: Removida a explicação do cálculo de equivalência — mantido apenas o resultado final com a fonte

SLIDE 5
- Antes: fonte citada apenas na legenda
- Depois: rodapé "Fonte: Portal da Transparência Ubatuba — Contratos 2023" adicionado ao slide
- Motivo: Reprovação na auditoria de visibilidade de fontes

SLIDE 8
- Antes: "Compartilha, comenta, salva esse carrossel e acessa o link na bio"
- Depois: "Protocole a denúncia no TCE-SP — leva 5 minutos e está no link da bio"
- Motivo: CTA com 4 ações simultâneas — reduzido a 1 ação com benefício explícito

CAPTION
- Antes: pergunta de encerramento genérica "O que você acha disso?"
- Depois: "Você conhece alguém que mora no Saco da Ribeira? Manda esse carrossel pra eles."
- Motivo: Pergunta genérica não especifica nenhuma ação — versão final converte engajamento em distribuição orgânica
```

---

## Veto Conditions

1. **Anti-commodity check reprovado sem correção:** Se o Teste da Substituição revelar slides genéricos e Igor não conseguir torná-los insubstituíveis com os dados disponíveis da história, o arquivo não é gerado como "final". Igor retorna para `create-instagram-feed.md`, solicita dados adicionais ao usuário (nome de bairro, comparação local específica, número do contrato) e reescreve antes de prosseguir.
2. **Hook reprovado nos três testes sem melhora:** Se o Slide 1 continuar falhando nos Testes do Polegar, WhatsApp e Especificidade após a primeira reescrita, Igor apresenta 3 opções alternativas de hook ao usuário antes de gerar o arquivo final. Não força uma versão que não passa nos critérios.

---

## Quality Criteria

1. O change log registra todas as alterações com a versão anterior, a versão posterior e o motivo específico — sem log vago como "melhorado para mais clareza".
2. O carrossel final passa nos 6 testes aplicados (3 por slide no stress test, Teste do Polegar, Teste do WhatsApp, Teste da Especificidade) sem exceções não documentadas.
3. Nenhum slide do arquivo final contém dado numérico sem fonte visível no próprio slide.
