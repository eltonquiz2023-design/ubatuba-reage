# Task: Create Instagram Feed

## Purpose
Write the complete carousel content (9 slides + caption + hashtags) using the angle selected by the user in `generate-angles.md`, seguindo o funil narrativo obrigatório do @ubatubareage.

**Referência de design obrigatória:** leia `squads/ubatuba-reage/pipeline/data/design-system.md` para entender o funil narrativo e o propósito de cada slide antes de escrever o copy.

## Input
- `angles.md` — with the user's selected angle clearly indicated
- Original story data from `news-ranking.md`
- `tone-of-voice.md` — squad tone reference
- `squads/ubatuba-reage/pipeline/data/design-system.md` — funil narrativo e regras de copy

## Output
- `instagram-feed-draft.md` — complete 9-slide carousel ready for optimization pass

---

## Process

### Step 1 — Load Selected Angle and Story Data
Read the confirmed angle from `angles.md`. Extract:
- The selected emotional driver (Indignação / Investigativo / Empoderamento / Memória / Urgência)
- The recommended framework (AIDA / PAS / SCQA)
- The hook suggested for Slide 1

Return to `news-ranking.md` and extract all factual data for the story:
- All monetary values with sources
- All names and their institutional roles
- Contract numbers, dates, document references
- Any direct quotes from public officials or documents

### Step 2 — Load Tone of Voice
Read `tone-of-voice.md` and identify the correct tone register for the selected angle:
- Indignação → Tom: Firme, sem adjetivos desnecessários. Deixa os fatos falarem.
- Investigativo → Tom: Curioso, metódico. Conduz o leitor passo a passo.
- Empoderamento → Tom: Direto, encorajador. "Você pode" — não "talvez seja possível".
- Memória → Tom: Narrativo, cronológico. Âncora em datas reais.
- Urgência → Tom: Conciso, imperativo. Sem rodeios.

### Step 3 — Write the 9-Slide Carousel (Funil Narrativo Obrigatório)

Estrutura obrigatória — cada slide responde a uma pergunta específica do leitor:

| Slide | Função       | Pergunta que responde                    | Fundo visual   |
|-------|--------------|------------------------------------------|----------------|
| 1     | CHOQUE       | "Por que eu deveria parar pra ler isso?" | ESCURO         |
| 2     | FATO         | "O que aconteceu?"                       | LARANJA        |
| 3     | CONTEXTO     | "Isso já aconteceu antes?"               | ESCURO         |
| 4     | PROVA        | "Quais são os números?"                  | LARANJA        |
| 5     | COMPARAÇÃO   | "O que isso significa pro meu bolso?"    | ESCURO         |
| 6     | REVELAÇÃO    | "E o que está acontecendo agora?"        | NAVY           |
| 7     | ACCOUNTABILITY | "Quem são os responsáveis?"            | CLARO          |
| 8     | CTA          | "O que EU posso fazer?"                  | ESCURO         |
| 9     | CREDIBILIDADE | "Por que confiar nessa informação?"     | ESCURO         |

Para cada slide, escrever os seguintes campos:

**Slides 1, 2, 4, 6, 7** (headline + conteúdo):
- `HEADLINE:` — em CAPS, máximo 8 palavras, com ponto final ou `?`
- `CORPO:` — texto principal (peso 800 para slides laranja/navy; peso 500+800 para escuros)
- `IMAGEM:` — descrição da composição para geração de imagem

**Slides 3, 5, 8** (texto dual: regular + bold, separados por seta):
- `CORPO REGULAR:` — contextualização factual, peso 500, 2–4 frases curtas
- `CORPO BOLD:` — conclusão emocional/dado de impacto, peso 800, termina com pergunta
- `IMAGEM:` — opcional (slide 5 e 8 podem ter apenas fundo sutil)

**Slide 9** (créditos):
- `FONTES:` — lista todas as fontes verificáveis usadas no carrossel
- `CTA FINAL:` — 3 verbos imperativos separados por ponto (ex: "Reaja. Compartilhe. Fiscalize.")

---

### Regras de copy obrigatórias

**Headlines (todos os slides):**
- SEMPRE uppercase
- SEMPRE com ponto final ou `?` (nunca reticências)
- Máximo 8 palavras (slide 1 pode ter até 12)
- Funciona como manchete de jornal
- Bons: "A CONTA É SUA.", "O NÚMERO MUDA. O MÉTODO NÃO.", "FALTA PROJETO. SOBRA URGÊNCIA."
- Ruins: "Entenda o que está acontecendo...", "Saiba mais sobre o PL"

**Corpo Regular (slides escuros, bloco 1):**
- Tom: jornalístico, factual, sem opinião
- Frases de 10–20 palavras
- Contextualiza, informa, prepara terreno

**Corpo Bold (slides escuros, bloco 2):**
- Tom: impactante, conclusivo, emocional
- Contém o dado mais impactante ou a pergunta mais incômoda
- SEMPRE termina com pergunta retórica (exceto slide 8 que termina com imperativo)
- Números SEMPRE com comparação de escala humana: "R$ 147 mi = 52% do IPTU anual"

**Slide 7 (Accountability):**
- SEMPRE nomeia pessoas, cargos e partidos (dados públicos)
- SEMPRE termina com pergunta: "quem vai responder?"

**Slide 8 (CTA):**
- Regular: resumo staccato — frases de 2–4 palavras separadas por ponto
- Bold: exatamente 3 ações (Primeira / Segunda / Terceira)
- CTA 2 SEMPRE inclui frase pronta entre aspas para o cidadão copiar e enviar
- Termina com imperativo que devolve poder ao cidadão

---

### Step 4 — Write the Caption

Estrutura da legenda:

1. **Hook (primeiros 125 caracteres):** deve ser idêntico ou variação direta do Slide 1. É o que aparece antes do "ver mais" no Instagram.
2. **Corpo:** 3–5 parágrafos curtos expandindo o contexto com os dados principais. Usa emojis como marcadores de parágrafo, nunca como decoração.
3. **Pergunta de encerramento:** uma pergunta que convida comentário genuíno — não "o que você acha?" mas algo específico à história.
4. **Divulgação de IA:** última linha: `[Conteúdo produzido com apoio de IA. Dados verificados por @ubatubareage.]`

### Step 5 — Select 10 Hashtags

Distribuição obrigatória:
- 5 hashtags de nicho (< 50K posts): específicas a Ubatuba, ativismo local, pauta da história
- 3 hashtags de médio alcance (50K–500K posts): ativismo cívico regional, transparência pública, SP
- 2 hashtags de amplo alcance (> 500K posts): uma temática nacional, uma de formato

Critério de seleção: relevância semântica à história > volume. Nunca usa hashtag genérica sem relação direta com o conteúdo.

---

## Output Format

```
=== FORMAT ===
Ângulo selecionado: [driver]
Framework: [AIDA/PAS/SCQA]
Número de slides: 9
Tom: [conforme tone-of-voice.md]

=== SLIDES ===

══════════════════════════════════════════════
SLIDE 01 — CHOQUE (fundo escuro)
══════════════════════════════════════════════
HEADLINE: [TEXTO EM CAPS COM PONTO OU ?]
SUBTÍTULO: [resumo em caps — 2 linhas, dados-chave do carrossel]
IMAGEM: [composição dramática com elementos simbólicos — tons escuros, acentos laranja]

══════════════════════════════════════════════
SLIDE 02 — FATO (fundo laranja)
══════════════════════════════════════════════
HEADLINE: [MÁXIMO 5 PALAVRAS.]
IMAGEM: [cena cinematográfica relacionada ao tema]
CORPO: [texto corrido peso 800, cor branco, explica o fato central com dados, termina com pergunta]

══════════════════════════════════════════════
SLIDE 03 — CONTEXTO (fundo escuro, texto dual)
══════════════════════════════════════════════
IMAGEM: [composição full-width, atmosfera dramática, sem margens laterais]
CORPO REGULAR: [contextualização histórica, peso 500, datas e fatos]
CORPO BOLD: [conclusão emocional, dado que choca, peso 800, termina com pergunta]

══════════════════════════════════════════════
SLIDE 04 — PROVA (fundo laranja)
══════════════════════════════════════════════
HEADLINE: [CONTÉM UM NÚMERO OU DADO ESPECÍFICO.]
IMAGEM: [paisagem da região ou cena simbólica que ancora na realidade local]
CORPO: [texto factual, frases curtas telegráficas, datas e valores, peso 500, cor preto]

══════════════════════════════════════════════
SLIDE 05 — COMPARAÇÃO (fundo escuro, texto dual)
══════════════════════════════════════════════
CORPO REGULAR: [padrão identificado, frases curtas declarativas, peso 500]
CORPO BOLD: [dado comparativo que traduz o número pro cotidiano, peso 800, termina com pergunta]
IMAGEM: [opcional — apenas fundo sutil com opacidade 10-20%]

══════════════════════════════════════════════
SLIDE 06 — REVELAÇÃO (fundo navy)
══════════════════════════════════════════════
HEADLINE: [FRASE DE VIRADA. O NÚMERO MUDA. O MÉTODO NÃO.]
IMAGEM: [a mais impactante do carrossel — atmosfera de thriller, tons quentes ao fundo]
CORPO: [consequência real e tangível na vida do cidadão, peso 800, cor branco]

══════════════════════════════════════════════
SLIDE 07 — ACCOUNTABILITY (fundo claro)
══════════════════════════════════════════════
HEADLINE: [FRASE DE COBRANÇA DIRETA.]
IMAGEM: [elementos concretos que remetem a gasto público — dinheiro, documentos]
CORPO: [nomeia responsáveis com cargo e partido, peso 800, cor preto, termina com pergunta]

══════════════════════════════════════════════
SLIDE 08 — CTA (fundo escuro, texto dual)
══════════════════════════════════════════════
CORPO REGULAR: [resumo staccato — frases de 2-4 palavras separadas por ponto]
CORPO BOLD: [Primeira: ação 1. Segunda: "frase pronta entre aspas para o cidadão enviar". Terceira: ação 3. Frase final imperativa devolvendo poder ao cidadão.]

══════════════════════════════════════════════
SLIDE 09 — CRÉDITOS (fundo escuro)
══════════════════════════════════════════════
FONTES: [lista todas as fontes verificáveis: portais de transparência, Câmara, etc.]
CTA FINAL: [3 verbos imperativos. Ex: "Reaja. Compartilhe. Fiscalize."]

=== CAPTION ===

[hook idêntico ao slide 1 — primeiros 125 caracteres]

📋 [parágrafo 1]

💸 [parágrafo 2]

🏚️ [parágrafo 3]

📂 [parágrafo 4 — link para fonte pública]

[pergunta de encerramento específica à história]

[Conteúdo produzido com apoio de IA. Dados verificados por @ubatubareage.]

=== HASHTAGS ===

Nicho (< 50K):
#ubatubareage #... (5 hashtags)

Médio alcance (50K–500K):
#... (3 hashtags)

Amplo alcance (> 500K):
#... (2 hashtags)
```

---

## Veto Conditions

1. **Dado sem fonte explicitada:** Se qualquer slide de dado (2, 4, 6) não especificar a fonte de onde o dado vem — não necessariamente no slide mas no briefing para Dani inserir — Igor adiciona a fonte antes de gerar o arquivo.
2. **Slide 1 não autossuficiente:** Se o Slide 1 precisar do Slide 2 para fazer sentido, reescreve o Slide 1. O hook deve comunicar a denúncia completa por si só.
3. **Slide 7 sem nomes:** Se o slide 7 não nomear ao menos uma pessoa com cargo e partido — reescreve antes de gerar.
4. **Slide 8 sem frase pronta:** Se o CTA 2 não tiver frase pronta entre aspas para o cidadão copiar e enviar — reescreve antes de gerar.
5. **Número de slides diferente de 9:** O carrossel tem exatamente 9 slides. Sem exceções.

---

## Quality Criteria

1. O Slide 1 para o scroll e contém fato + cifra + implicação — sem abrir o carrossel o morador já entendeu a denúncia.
2. Alternância de ton/impacto funciona: slides laranja são assertivos, slides escuros têm virada regular→bold.
3. O ângulo selecionado é o tom dominante em todos os 9 slides.
4. A legenda tem exatamente 1 pergunta de encerramento específica à história, não genérica.
5. Números com comparação de escala humana em pelo menos 2 slides.
6. A divulgação de IA está na última linha da legenda.
