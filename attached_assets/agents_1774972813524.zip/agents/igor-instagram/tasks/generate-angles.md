# Task: Generate Angles

## Purpose
Generate 5 distinct emotional angles from ONE selected news story so the user can choose the strategic frame before any content is written.

## Input
- Selected story from `news-ranking.md` (user must have indicated which story they want to work with)

## Output
- `angles.md` — numbered list of 5 emotional angles, each with hook, framework, moral driver, and emoji indicator

---

## Process

### Step 1 — Read the Selected Story
Load the story entry from `news-ranking.md`. Extract:
- Core fact (what happened)
- Key figures (names, values in R$, dates, contract numbers)
- Institutional actor (which secretaria, empresa, vereador, or prefeito)
- Available evidence (document type, source URL, transparency portal link)
- Potential victims or beneficiaries (moradores, servidores, bairros afetados)

Do not proceed if the story lacks at least one verifiable source.

### Step 2 — Identify the Dominant Moral Foundation (Haidt)
Classify the story against Haidt's moral foundations and identify the PRIMARY one that will resonate most with the @ubatubareage audience:

| Foundation | Trigger Question |
|---|---|
| Cuidado/Dano | Alguém foi prejudicado concretamente? Quem perdeu o quê? |
| Justiça/Trapaça | Alguém burlou uma regra e se beneficiou? |
| Lealdade/Traição | Uma pessoa de confiança traiu a comunidade? |
| Autoridade/Subversão | Uma instituição abusou do poder que lhe foi delegado? |
| Liberdade/Opressão | Um grupo foi silenciado, ignorado ou privado de direitos? |

Note the primary foundation and any secondary foundation present. This informs which angles will have the strongest organic reach.

### Step 3 — Generate 5 Angles Using Different Emotional Drivers
Create one angle for each emotional driver below. Each angle must be genuinely distinct — different hook logic, different narrative arc, different audience activation:

| # | Driver | Core Logic |
|---|---|---|
| 1 | Indignação | Expõe o ato, nomeia o responsável, gera raiva direcionada |
| 2 | Investigativo | Segue o dinheiro ou o documento — o morador vira detetive junto |
| 3 | Empoderamento | Mostra o que o morador pode fazer agora com essa informação |
| 4 | Memória | Conecta o fato atual com uma promessa passada não cumprida |
| 5 | Urgência | Há um prazo, uma votação, uma licitação — age agora ou perde |

### Step 4 — Build Each Angle Entry
For each angle, produce:

```
ÂNGULO [N] — [DRIVER]
Hook sugerido: [1 frase máximo — o Slide 1]
Framework recomendado: [AIDA / PAS / SCQA] + justificativa em 1 linha
Fundação moral ativada: [fundação primária + secundária se houver]
Perfil de engajamento estimado: [Compartilhamentos / Saves / Comentários] como driver principal + razão
Indicador: [emoji que representa o tom do ângulo]
```

### Step 5 — Present for User Selection
Present all 5 angles numerados. Ask the user to select one before proceeding to `create-instagram-feed.md`. Do not write any carousel body copy until the angle is confirmed.

---

## Output Format

```
# Ângulos para: [TÍTULO DA HISTÓRIA]
Fonte: [nome da fonte + URL ou referência ao portal]
Fundação moral dominante: [nome]

---

ÂNGULO 1 — INDIGNAÇÃO 🔥
Hook sugerido: "A Prefeitura de Ubatuba pagou R$ 480 mil por um parque que nunca foi construído."
Framework recomendado: PAS — o problema é claro, a agitação vem dos detalhes do contrato, a solução é exigir a devolução.
Fundação moral ativada: Justiça/Trapaça (primária) + Cuidado/Dano (secundária)
Perfil de engajamento estimado: Compartilhamentos como driver principal — indignação direta gera "olha isso" no WhatsApp.
Indicador: 🔥

---

ÂNGULO 2 — INVESTIGATIVO 🔍
Hook sugerido: "Esse contrato tem 3 irregularidades. Encontramos as 3 no Portal da Transparência."
Framework recomendado: SCQA — Situação (contrato assinado), Complicação (cláusulas irregulares), Questão (quem aprovou?), Ação (veja os documentos).
Fundação moral ativada: Autoridade/Subversão (primária)
Perfil de engajamento estimado: Saves como driver principal — conteúdo de referência que as pessoas guardam para mostrar depois.
Indicador: 🔍

---

ÂNGULO 3 — EMPODERAMENTO 💪
Hook sugerido: "Você pode cancelar esse contrato. Veja como em 4 passos."
Framework recomendado: AIDA — Atenção (você tem poder), Interesse (os 4 passos), Desejo (imagina se todo morador fizer isso), Ação (protocolo de denúncia).
Fundação moral ativada: Liberdade/Opressão (primária)
Perfil de engajamento estimado: Saves + Comentários — "salvei para usar" e "mandei para o vereador".
Indicador: 💪

---

ÂNGULO 4 — MEMÓRIA 📜
Hook sugerido: "Em 2021 prometeram o parque. Em 2024 pagaram por ele. Em 2025 ainda não existe."
Framework recomendado: PAS — Problema (promessa), Agitação (linha do tempo das promessas vs. realidade), Solução (cobrar publicamente com data).
Fundação moral ativada: Lealdade/Traição (primária) + Justiça/Trapaça (secundária)
Perfil de engajamento estimado: Compartilhamentos — "eu lembro disso" é uma das emoções mais virais no ativismo local.
Indicador: 📜

---

ÂNGULO 5 — URGÊNCIA ⏰
Hook sugerido: "A Câmara vota amanhã. Se ninguém aparecer, aprovam mais R$ 200 mil para a mesma empresa."
Framework recomendado: SCQA — Situação (votação marcada), Complicação (histórico de irregularidades), Questão (o que acontece se não houver pressão?), Ação (vai à sessão ou assina a petição).
Fundação moral ativada: Liberdade/Opressão (primária) + Autoridade/Subversão (secundária)
Perfil de engajamento estimado: Comentários + Compartilhamentos — urgência ativa mobilização imediata, não apenas salvamento.
Indicador: ⏰

---

Qual ângulo você quer desenvolver? Digite o número (1–5).
```

---

## Veto Conditions

1. **Story sem fonte verificável:** Se a história não tiver link para Portal da Transparência, documento oficial, matéria jornalística ou registro público, Igor não gera ângulos. Informa o usuário e solicita que Sofia Notícias adicione a fonte antes de prosseguir.
2. **Ângulos redundantes:** Se dois ângulos gerados forem essencialmente o mesmo frame com palavras diferentes, Igor os substitui antes de apresentar. Os 5 ângulos devem ativar emoções ou mecanismos de engajamento genuinamente distintos.

---

## Quality Criteria

1. Cada um dos 5 ângulos ativa um driver emocional diferente — nenhum sobrepõe outro.
2. O hook sugerido de cada ângulo é específico o suficiente para ser postado sem alteração — nenhum hook genérico como "você sabia que..." ou "a prefeitura fez algo errado".
3. A fundação moral identificada no Step 2 é visível em pelo menos 3 dos 5 ângulos — a escolha do usuário determina qual fundação vai para o centro do carrossel.
