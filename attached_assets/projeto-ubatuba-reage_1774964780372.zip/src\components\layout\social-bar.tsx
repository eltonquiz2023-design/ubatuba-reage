import React from "react";
import Link from "next/link";
import {
  WhatsAppIcon,
  XIcon,
  InstagramIcon,
  FacebookIcon,
  YouTubeIcon,
} from "@/components/icons";

const socials = [
  { icon: InstagramIcon, href: "https://instagram.com/ubatubaReage",  label: "Instagram" },
  { icon: WhatsAppIcon,  href: "https://wa.me/message/ubatubaReage",  label: "WhatsApp" },
  { icon: FacebookIcon,  href: "https://facebook.com/ubatubaReage",    label: "Facebook" },
  { icon: YouTubeIcon,   href: "https://youtube.com/@ubatubaReage",    label: "YouTube" },
  { icon: XIcon,         href: "https://x.com/ubatubaReage",           label: "X" },
];

export function SocialBar() {
  return (
    <div className="bg-[#0a0a0a] border-b border-white/5 flex items-center justify-end gap-1 px-4 h-10">
      {socials.map(({ icon: Icon, href, label }) => (
        <Link
          key={label}
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          aria-label={label}
          className="w-9 h-9 flex items-center justify-center text-white/60 hover:text-white transition-colors"
        >
          <Icon className="w-[18px] h-[18px]" />
        </Link>
      ))}
    </div>
  );
}
