import Link from "next/link";
import { Header } from "@/components/layout/header";

export default function NotFound() {
  return (
    <>
      <div className="hidden lg:block fixed top-0 left-0 bottom-0 w-[260px] bg-[#0a0a0a] z-40" />
      <Header />
      <div className="flex min-h-screen">
        <div className="hidden lg:block flex-shrink-0 w-[260px]" />
        <main className="flex-1 flex flex-col items-center justify-center p-10 bg-[#f5f5f5]">
          <div className="lg:hidden h-[96px]" />
          <span className="text-[#4B59F7] font-mono font-bold text-sm uppercase tracking-[0.2em] mb-4">
            404
          </span>
          <h1 className="text-black text-4xl font-black uppercase tracking-tight text-center max-w-lg mb-4">
            Matéria não encontrada
          </h1>
          <p className="text-gray-500 text-center font-serif italic text-lg mb-8 max-w-md">
            A reportagem que você procura não existe ou foi removida de nosso
            arquivo.
          </p>
          <Link
            href="/"
            className="inline-flex items-center gap-2 bg-[#4B59F7] text-white font-mono font-bold uppercase tracking-[0.15em] text-xs px-6 py-3 hover:bg-[#3a48e0] transition-colors"
          >
            ← Voltar para o início
          </Link>
        </main>
      </div>
    </>
  );
}
