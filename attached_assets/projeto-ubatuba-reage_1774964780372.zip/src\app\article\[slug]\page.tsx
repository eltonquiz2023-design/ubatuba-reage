import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";

/* ── Article Data Type ── */
interface ArticleData {
  slug: string;
  category: string;
  title: string;
  lead: string;
  author: string;
  date: string;
  readingTime: string;
  imageUrl: string;
  imageCaption: string;
  body: string[];
}

/* ── Mock article database ── */
const articles: Record<string, ArticleData> = {
  "ia-tecnofascismo": {
    slug: "ia-tecnofascismo",
    category: "Tecnologia",
    title: "Entrevista: Como a IA abre caminho para o tecnofascismo",
    lead: "Pesquisador da Universidade de Viena defende que tecnologias não são politicamente neutras e que a comodidade oferecida por algoritmos remove o esforço crítico e torna as pessoas mais vulneráveis à manipulação.",
    author: "Lais Martins",
    date: "26 de março de 2026",
    readingTime: "8 min de leitura",
    imageUrl: "https://picsum.photos/seed/ia-fascismo/1200/675",
    imageCaption: "Representação artística de interface de IA com símbolos históricos de autoritarismo. Crédito: Midjourney / The Intercept Brasil",
    body: [
      "O pesquisador austríaco Ulrich Brand passou os últimos anos estudando como as grandes plataformas de tecnologia moldam o comportamento político das massas. Em entrevista ao The Intercept Brasil, ele defende que a inteligência artificial — longe de ser uma ferramenta neutra — está sendo instrumentalizada para consolidar estruturas de poder que historicamente chamávamos de fascismo.",
      "\"A IA não é política em si, mas quem a controla e para quê ela é usada, isso é profundamente político\", afirma Brand. \"Quando você deixa um algoritmo decidir o que você lê, o que você compra, com quem você se relaciona — você está delegando sua autonomia a um sistema projetado para maximizar engajamento, não para promover pensamento crítico.\"",
      "Brand aponta que o maior perigo não está nos usos mais óbvios da tecnologia — deepfakes, desinformação, vigilância em massa —, mas na erosão silenciosa da capacidade de as pessoas reconhecerem a manipulação quando ela acontece.",
      "\"A comodidade é o veículo\", ele explica. \"Quando o algoritmo do YouTube te dá exatamente o vídeo que você queria ver, quando o Spotify cuida da sua playlist, quando o Google Maps te poupa de pensar no caminho — você fica mais e mais dependente de sistemas externos para tomar decisões. E aí, quando esse mesmo sistema começa a te direcionar politicamente, você já não tem mais o músculo intelectual para questionar.\"",
      "O pesquisador traça um paralelo com o período entre guerras do século XX, quando o rádio e o cinema foram centrais para a ascensão de movimentos autoritários na Europa.",
      "\"A diferença é que hoje os sistemas são individualizados. O rádio de Goebbels falava para todos ao mesmo tempo — todos ouviam a mesma mensagem. Hoje, cada pessoa recebe uma versão da realidade personalizada para ela. Isso torna a manipulação muito mais eficiente e muito mais difícil de combater, porque não existe mais um 'consenso de fatos' sobre o qual a democracia possa se apoiar.\"",
      "Quando perguntado sobre soluções, Brand é cauteloso. \"Não sou ludita. Não estou dizendo que devemos destruir as máquinas. Mas precisamos de regulação séria, de educação midiática massiva e, sobretudo, de uma consciência coletiva de que essas ferramentas não são neutras.\" Ele aponta para iniciativas como o AI Act europeu como um passo na direção certa, mas insuficiente.",
      "\"A velocidade da regulação nunca vai acompanhar a velocidade da inovação tecnológica. Por isso, a única defesa duradoura é uma cidadania crítica. E isso começa com a educação — não de como usar o TikTok, mas de como questionar por que certos conteúdos chegam até você e não outros.\"",
    ],
  },
  "trump-america-latina": {
    slug: "trump-america-latina",
    category: "América Latina",
    title: "Trump mira na América Latina e os ataques estão só começando",
    lead: "Estratégia de segurança nacional dos EUA revela planos de Trump: retomar domínio da região com força militar e aliados de extrema direita.",
    author: "Nick Turse",
    date: "25 de março de 2026",
    readingTime: "12 min de leitura",
    imageUrl: "https://picsum.photos/seed/trump-latam/1200/675",
    imageCaption: "Mapa da América Latina com pontos indicando bases militares dos EUA e aliados políticos. Crédito: The Intercept Brasil",
    body: [
      "Um documento de 47 páginas obtido pelo The Intercept Brasil revela que a administração Trump preparou uma estratégia abrangente para reafirmar a dominância dos Estados Unidos na América Latina, incluindo o uso de pressão econômica, operações de informação e, em casos extremos, intervenção militar indireta via aliados regionais.",
      "O documento, datado de fevereiro de 2026 e classificado como 'Sensível mas não classificado', foi vazado por uma fonte no Conselho de Segurança Nacional que descreveu o plano como 'a Doutrina Monroe com esteroides e inteligência artificial'.",
      "A estratégia identifica seis países como 'vulneráveis à influência adversarial' — eufemismo que inclui governos de esquerda e centros com políticas externas independentes: Brasil, México, Colômbia, Chile, Peru e Bolívia.",
      "Segundo o documento, os EUA planejam intensificar a presença de forças especiais em pelo menos quatro países da região nos próximos 18 meses, com foco em 'treinamento e capacitação' de forças locais — um modelo já testado na Colômbia e Honduras.",
      "Fontes no governo brasileiro ouvidas pela reportagem afirmam que Brasília está ciente do documento e está em processo de 'consultas diplomáticas' com aliados europeus e sul-americanos sobre uma resposta coordenada.",
    ],
  },
  "cpi-crime-organizado": {
    slug: "cpi-crime-organizado",
    category: "Segurança",
    title: "Nova CPI do crime organizado debate o que Brasil já sabe há 20 anos",
    lead: "Quatro comissões parlamentares em duas décadas já provaram que as armas do crime organizado e a corrupção policial são os principais motores da violência urbana.",
    author: "Bruno Fonseca",
    date: "24 de março de 2026",
    readingTime: "10 min de leitura",
    imageUrl: "https://picsum.photos/seed/cpi-crime/1200/675",
    imageCaption: "Sessão da CPI do Crime Organizado no Congresso Nacional. Crédito: Agência Câmara",
    body: [
      "A nova CPI do Crime Organizado, instalada na Câmara dos Deputados em março de 2026, promete investigar as conexões entre facções criminosas, milícias e setores do Estado. O problema: tudo o que ela promete descobrir já foi descoberto, documentado e ignorado.",
      "Uma análise de relatórios de quatro CPIs realizadas entre 2005 e 2023 — sobre tráfico de armas, milícias, narcotráfico e segurança pública — revela uma sobreposição impressionante de conclusões: armas de origem policial alimentam as facções, policiais participam diretamente de atividades criminosas, e o controle territorial do crime organizado avança nos vácuos deixados pelo Estado.",
      "\"Já fizemos esse diagnóstico. Já sabemos o que precisa ser feito. O que falta é vontade política\", diz o criminologista Julião Pontes, da Universidade Federal Fluminense, que acompanhou todas as comissões como consultor.",
      "A diferença desta CPI, segundo seus defensores, é o foco em conexões internacionais — especialmente com o Primeiro Comando da Capital (PCC), que expandiu significativamente suas operações para o Paraguai, Bolívia e Europa nos últimos cinco anos.",
    ],
  },
  placeholder: {
    slug: "placeholder",
    category: "Política",
    title: "Artigo de demonstração do clone",
    lead: "Esta é uma página de artigo de demonstração, criada para mostrar o layout fiel ao Intercept Brasil no projeto de clonagem.",
    author: "Equipe Intercept",
    date: "31 de março de 2026",
    readingTime: "5 min de leitura",
    imageUrl: "https://picsum.photos/seed/demo-article/1200/675",
    imageCaption: "Imagem de demonstração do clone do Intercept Brasil.",
    body: [
      "Este é o layout de artigo do clone do The Intercept Brasil. A estrutura replica fielmente o design original, incluindo a sidebar escura, a barra de redes sociais, o cabeçalho do artigo com categoria, título em caixa alta, lead em itálico, e a área de leitura.",
      "O projeto usa Next.js com TypeScript, fontes proprietárias do Intercept (TIActuBeta), e a paleta de cores exata extraída do site original (#4B59F7 para links e destaques, fundos cinza para a área de conteúdo).",
      "A próxima etapa é implementar artigos dinâmicos conectados a um CMS ou API.",
    ],
  },
};

/* Related articles (sidebar) */
const relatedArticles = [
  {
    slug: "desinformacao-eleicoes",
    category: "Eleições 2026",
    title: "Redes de desinformação já mapeiam candidatos para 2026",
    imageUrl: "https://picsum.photos/seed/desinformacao-2026/400/225",
  },
  {
    slug: "mineracao-indigena",
    category: "Meio Ambiente",
    title: "Garimpo avança 340% em terras indígenas",
    imageUrl: "https://picsum.photos/seed/garimpo-indigena/400/225",
  },
  {
    slug: "flavio-bolsonaro-manchetes",
    category: "Política",
    title: "Flávio Bolsonaro perde sobrenome nas manchetes da imprensa",
    imageUrl: "https://picsum.photos/seed/flavio-slogan/400/225",
  },
  {
    slug: "sigilo-lulinha",
    category: "Justiça",
    title: "STJ mantém sigilo de investigação sobre negócios de Lulinha",
    imageUrl: "https://picsum.photos/seed/lulinha-stj/400/225",
  },
];

export default async function ArticlePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const article = articles[slug];

  if (!article) notFound();

  // Filter out current article from related
  const related = relatedArticles.filter((a) => a.slug !== slug).slice(0, 4);

  return (
    <>
      {/* Fixed black sidebar background (desktop) */}
      <div className="hidden lg:block fixed top-0 left-0 bottom-0 w-[260px] bg-[#0a0a0a] z-40" />

      <Header />

      <div className="flex min-h-screen">
        {/* Sidebar spacer */}
        <div className="hidden lg:block flex-shrink-0 w-[260px]" />

        {/* Main content */}
        <main className="flex-1 flex flex-col min-w-0 bg-white">
          {/* Mobile spacers */}
          <div className="lg:hidden h-[56px]" />
          <div className="h-10" />

          {/* Article header area — light gray bg */}
          <div className="bg-[#f5f5f5] px-5 md:px-10 lg:px-16 pt-8 pb-10">
            {/* Breadcrumb */}
            <div className="flex items-center gap-2 mb-6">
              <Link href="/" className="text-[#4B59F7] text-[11px] font-mono font-bold uppercase tracking-[0.15em] hover:underline">
                Home
              </Link>
              <span className="text-gray-400 text-[11px]">/</span>
              <span className="text-[#4B59F7] text-[11px] font-mono font-bold uppercase tracking-[0.15em]">
                {article.category}
              </span>
            </div>

            {/* Headline */}
            <h1 className="text-black text-3xl md:text-4xl lg:text-5xl font-black leading-[1.05] tracking-tight uppercase max-w-4xl mb-6">
              {article.title}
            </h1>

            {/* Lead */}
            <p className="text-gray-600 text-lg md:text-xl font-serif italic leading-relaxed max-w-3xl mb-8">
              {article.lead}
            </p>

            {/* Author / Date / Reading time bar */}
            <div className="flex flex-wrap items-center gap-x-4 gap-y-2 pt-5 border-t border-black/10">
              <span className="text-black text-sm font-bold font-mono uppercase tracking-widest">
                {article.author}
              </span>
              <span className="text-gray-300">|</span>
              <span className="text-gray-500 text-xs font-mono uppercase tracking-widest">
                {article.date}
              </span>
              <span className="text-gray-300">|</span>
              <span className="text-gray-500 text-xs font-mono uppercase tracking-widest">
                {article.readingTime}
              </span>

              {/* Share buttons */}
              <div className="ml-auto flex items-center gap-2">
                <span className="text-gray-400 text-[10px] font-mono uppercase tracking-widest hidden sm:block">Compartilhar:</span>
                <a
                  href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(article.title)}&url=${encodeURIComponent(`https://theintercept.com.br/article/${article.slug}`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-7 h-7 flex items-center justify-center bg-black text-white hover:bg-[#4B59F7] transition-colors text-xs font-bold"
                  aria-label="Compartilhar no X"
                >
                  𝕏
                </a>
                <a
                  href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(`https://theintercept.com.br/article/${article.slug}`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-7 h-7 flex items-center justify-center bg-[#1877F2] text-white hover:bg-[#4B59F7] transition-colors text-xs font-bold"
                  aria-label="Compartilhar no Facebook"
                >
                  f
                </a>
                <a
                  href={`https://api.whatsapp.com/send?text=${encodeURIComponent(`${article.title} — https://theintercept.com.br/article/${article.slug}`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-7 h-7 flex items-center justify-center bg-[#25D366] text-white hover:bg-[#4B59F7] transition-colors text-xs font-bold"
                  aria-label="Compartilhar no WhatsApp"
                >
                  W
                </a>
              </div>
            </div>
          </div>

          {/* Hero image — full width of content area */}
          <div className="relative w-full aspect-[16/7] bg-gray-200">
            <Image
              src={article.imageUrl}
              alt={article.title}
              fill
              sizes="(max-width: 1024px) 100vw, calc(100vw - 260px)"
              className="object-cover"
              priority
            />
          </div>
          {/* Image caption */}
          <div className="bg-[#f5f5f5] px-5 md:px-10 lg:px-16 py-2">
            <p className="text-gray-400 text-xs font-mono italic">
              {article.imageCaption}
            </p>
          </div>

          {/* Article body + Sidebar layout */}
          <div className="flex gap-0 items-start">
            {/* Main article body */}
            <div className="flex-1 min-w-0">
              <article className="px-5 md:px-10 lg:px-16 py-10 max-w-3xl">
                {article.body.map((paragraph, i) => (
                  <p
                    key={i}
                    className="text-gray-800 text-lg leading-[1.8] mb-6 font-serif"
                  >
                    {paragraph}
                  </p>
                ))}
              </article>

              {/* Tags */}
              <div className="px-5 md:px-10 lg:px-16 pb-8 flex flex-wrap gap-2">
                <span className="text-[10px] font-mono font-black uppercase tracking-[0.15em] text-gray-400 self-center mr-2">Tags:</span>
                {[article.category, "Intercept Brasil", "Jornalismo investigativo"].map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1 border border-black/20 text-[10px] font-mono font-bold uppercase tracking-[0.1em] text-gray-600 hover:border-[#4B59F7] hover:text-[#4B59F7] cursor-pointer transition-colors"
                  >
                    {tag}
                  </span>
                ))}
              </div>

              {/* Divider */}
              <div className="mx-5 md:mx-10 lg:mx-16 border-t border-black/10" />

              {/* Back to home */}
              <div className="px-5 md:px-10 lg:px-16 py-8">
                <Link
                  href="/"
                  className="inline-flex items-center gap-2 text-[#4B59F7] font-mono font-bold uppercase tracking-[0.15em] text-xs hover:underline"
                >
                  ← Voltar para Matérias
                </Link>
              </div>
            </div>

            {/* Related articles sidebar (desktop only) */}
            <aside className="hidden xl:block w-[320px] flex-shrink-0 border-l border-black/10 bg-[#fafafa] self-stretch">
              <div className="sticky top-[40px] p-6">
                <h3 className="text-[10px] font-black uppercase tracking-[0.2em] font-mono text-gray-400 border-b border-black/10 pb-4 mb-6">
                  Leia Também
                </h3>
                <div className="flex flex-col gap-6">
                  {related.map((rel) => (
                    <Link
                      key={rel.slug}
                      href={`/article/${rel.slug}`}
                      className="group flex flex-col gap-2"
                    >
                      <div className="relative w-full aspect-[16/9] bg-gray-200 overflow-hidden">
                        <Image
                          src={rel.imageUrl}
                          alt={rel.title}
                          fill
                          sizes="320px"
                          className="object-cover group-hover:scale-[1.03] transition-transform duration-500 ease-out"
                        />
                      </div>
                      <span className="text-[#4B59F7] text-[9px] font-black uppercase tracking-[0.15em] font-mono">
                        {rel.category}
                      </span>
                      <h4 className="text-black text-sm font-black leading-tight tracking-tight group-hover:underline decoration-1 underline-offset-2 uppercase">
                        {rel.title}
                      </h4>
                    </Link>
                  ))}
                </div>

                {/* Newsletter CTA in sidebar */}
                <div className="mt-8 p-4 bg-[#4B59F7] text-white">
                  <p className="text-[10px] font-mono font-black uppercase tracking-[0.15em] mb-2">Newsletter</p>
                  <p className="text-sm font-bold leading-tight mb-4">Receba as principais reportagens do Intercept na sua caixa de entrada</p>
                  <Link
                    href="/newsletter"
                    className="block text-center border border-white text-white hover:bg-white hover:text-[#4B59F7] transition-colors py-2 text-[11px] font-black uppercase tracking-[0.15em] font-mono"
                  >
                    Assinar
                  </Link>
                </div>
              </div>
            </aside>
          </div>

          {/* Footer */}
          <Footer />
        </main>
      </div>
    </>
  );
}

/* ── Static params for known slugs ── */
export function generateStaticParams() {
  return Object.keys(articles).map((slug) => ({ slug }));
}

/* ── Metadata Generation ── */
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const article = articles[slug];
  if (!article) return {};
  return {
    title: `${article.title} | The Intercept Brasil`,
    description: article.lead,
    openGraph: {
      title: article.title,
      description: article.lead,
      images: [{ url: article.imageUrl }],
    },
  };
}
