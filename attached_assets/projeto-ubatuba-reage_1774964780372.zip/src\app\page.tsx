import React from "react";
import { Header } from "@/components/layout/header";
import { DonationBanner } from "@/components/layout/donation-banner";
import { Footer } from "@/components/layout/footer";
import { ArticleRow, LoadMoreButton } from "@/components/home/article-feed";
import Image from "next/image";
import Link from "next/link";

/* ─── Placeholder article data ─── */
const featuredArticles = [
  {
    slug: "camara-aprova-contrato-sem-licitacao",
    category: "Denúncia: Má Gestão",
    title: "Câmara aprova R$ 2,4 milhões em obra sem licitação — e nenhum vereador questiona",
    lead: "Em sessão fechada, 11 vereadores aprovaram gasto milionário em empresa sem histórico em obras públicas. A população não foi consultada. O erro foi planejado.",
    date: "28 de março",
    author: "Ubatuba Reage",
    imageUrl: "https://picsum.photos/seed/camara-ubatuba/800/450",
  },
  {
    slug: "hospital-sem-estrutura-ubatuba",
    category: "Saúde Precária",
    title: "Hospital Municipal opera sem UTI, sem médicos e sem vergonha na cara",
    lead: "Pacientes aguardam transferência por dias em macas de corredor. Famílias relatam desamparo total em momentos críticos. A Prefeitura não responde.",
    date: "27 de março",
    author: "Fernanda Lima",
    imageUrl: "https://picsum.photos/seed/hospital-ubatuba/800/450",
  },
];

const feedArticles = [
  {
    slug: "iptu-aumento-abusivo-2025",
    category: "Custo de Vida",
    title: "IPTU sobe até 67% em 2025 enquanto serviços públicos afundam",
    lead: "Moradores receberam carnets com reajustes sem qualquer justificativa técnica. Enquanto isso, as ruas continuam esburacadas e a coleta de lixo falha toda semana.",
    date: "26 de março",
    author: "Carlos Mendes",
    imageUrl: "https://picsum.photos/seed/iptu-ubatuba/800/450",
  },
  {
    slug: "esgoto-a-ceu-aberto-centro",
    category: "Saneamento",
    title: "Esgoto a céu aberto no Centro: um escandalo que dura anos e ninguém resolve",
    lead: "Moradores do centro histórico convivem com mau cheiro, riscos de doenças e a indiferença da Prefeitura. O mesmo problema foi prometido como resolvido em 2022 e 2023.",
    date: "25 de março",
    author: "Ana Paula Rocha",
    imageUrl: "https://picsum.photos/seed/esgoto-ubatuba/800/450",
  },
  {
    slug: "escola-estadual-sem-professores",
    category: "Educação",
    title: "Escola fica 3 meses sem professor de matemática e Estado não age",
    lead: "Alunos de ensino médio de Ubatuba perderam um semestre letivo inteiro por falta de remodelação do quadro docente. A Diretoria de Ensino sabia e ficou calada.",
    date: "24 de março",
    author: "João Gomes",
    imageUrl: "https://picsum.photos/seed/escola-ubatuba/800/450",
  },
  {
    slug: "obra-avenida-parada-2-anos",
    category: "Abandono Público",
    title: "Obra parada há 2 anos na Av. Iperoig: a foto que vale mais que mil processos",
    lead: "A construção foi interrompida sem explicação em 2023. Desde então, a área vira ponto de descarte irregular de lixo e não tem previsão de retomada.",
    date: "22 de março",
    author: "Luciana Torres",
    imageUrl: "https://picsum.photos/seed/obra-parada/800/450",
  },
  {
    slug: "violencia-bairros-perifericos",
    category: "Segurança",
    title: "Bairros da periferia registram aumento de 40% na violência e PM some das ruas",
    lead: "Moradores das áreas mais afastadas relatam ausência de patrulhamento há meses. Enquanto isso, o Carnaval do centro recebe policiamento máximo.",
    date: "20 de março",
    author: "Marcos Vieira",
    imageUrl: "https://picsum.photos/seed/violencia-uba/800/450",
  },
  {
    slug: "turismo-x-moradores-crise",
    category: "Identidade Caiçara",
    title: "O turismo enriquece a cidade — mas quem paga a conta é o morador",
    lead: "A cidade bate recordes de visitantes enquanto moradores não conseguem pagar aluguel, faltam vagas nas UBSs e a praia mais bonita virou lixeiro. A beleza natural não mascara a realidade social.",
    date: "18 de março",
    author: "Ubatuba Reage",
    imageUrl: "https://picsum.photos/seed/turismo-ubatuba/800/450",
  },
];

export default function Home() {
  return (
    <>
      {/* ── Fixed sidebar background panel (desktop only) ── */}
      <div className="hidden lg:block fixed top-0 left-0 bottom-0 w-[260px] bg-[#111111] z-40" />

      {/* ── Header (sidebar on desktop, top bar on mobile) ── */}
      <Header />

      {/* ── Page layout ── */}
      <div className="flex min-h-screen">
        {/* Sidebar spacer pushes content to the right on desktop */}
        <div className="hidden lg:block flex-shrink-0 w-[260px]" />

        {/* Main content column */}
        <main className="flex-1 flex flex-col min-w-0">
          {/* Desktop: space below fixed social bar (40px) */}
          <div className="hidden lg:block h-10" />

          {/* Hero Section */}
          <Link href={`/article/${featuredArticles[0].slug}`} className="relative block w-full h-[480px] lg:h-screen bg-black overflow-hidden group">
            {/* Background Image */}
            <Image 
              src={featuredArticles[0].imageUrl} 
              alt={featuredArticles[0].title} 
              fill 
              className="object-cover opacity-70 group-hover:scale-105 transition-transform duration-700 ease-out" 
            />
            
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
            
            {/* Content overlay */}
            <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-12 z-10">
              <div className="max-w-[800px]">
                <div className="flex items-center gap-3 mb-4">
                  <span className="bg-[#4B59F7] text-white text-[11px] font-bold uppercase tracking-widest px-3 py-1">
                    {featuredArticles[0].category}
                  </span>
                </div>
                
                <h1 className="text-white text-4xl lg:text-6xl font-bold leading-[1.05] tracking-tight mb-4 group-hover:underline decoration-white decoration-2 underline-offset-8">
                  {featuredArticles[0].title}
                </h1>
                
                <p className="text-white/80 text-lg lg:text-xl font-serif italic leading-relaxed mb-6 line-clamp-2">
                  {featuredArticles[0].lead}
                </p>
                
                <div className="flex items-center gap-2 text-white/50 text-xs font-mono uppercase tracking-widest">
                  <span>{featuredArticles[0].date}</span>
                  <span className="text-white/30">—</span>
                  <span className="text-white font-black">{featuredArticles[0].author}</span>
                </div>
              </div>
            </div>
          </Link>

          {/* Article content area */}
          <div className="flex-1 bg-[#f5f5f5]">
            {/* Horizontal article feed rows */}
            <div className="bg-white">
              <ArticleRow {...featuredArticles[1]} />
              
              {feedArticles.map((article, index) => (
                <React.Fragment key={article.slug}>
                  <ArticleRow {...article} />
                  {/* Insert banner after the 2nd article */}
                  {index === 0 && (
                    <div className="bg-[#f5f5f5] py-1 border-y border-black/5">
                      <DonationBanner />
                    </div>
                  )}
                </React.Fragment>
              ))}
            </div>

            <LoadMoreButton />
          </div>

          {/* Footer */}
          <Footer />
        </main>
      </div>
    </>
  );
}
