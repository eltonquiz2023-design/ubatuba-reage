import React from "react";
import Image from "next/image";
import Link from "next/link";
import { cn } from "@/lib/utils";

interface HeroArticleProps {
  category: string;
  title: string;
  summary: string;
  author: string;
  date: string;
  imageUrl: string;
}

export function HeroArticle({ category, title, summary, author, date, imageUrl }: HeroArticleProps) {
  return (
    <article className="group cursor-pointer">
      <Link href="/article/placeholder" className="flex flex-col gap-6">
        {/* Figure / Image */}
        <div className="relative aspect-[16/9] w-full overflow-hidden bg-zinc-900 border border-white/5">
          <Image 
            src={imageUrl} 
            alt={title}
            fill
            className="object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
            priority
          />
        </div>

        {/* Content Container */}
        <div className="flex flex-col gap-3 px-4 lg:px-0">
          <span className="text-[#5640fb] font-bold text-xs uppercase tracking-widest">
            {category}
          </span>
          
          <h2 className="text-3xl lg:text-5xl font-bold leading-[1.1] tracking-tight group-hover:underline decoration-1 underline-offset-4">
            {title}
          </h2>

          <p className="text-zinc-400 text-lg lg:text-xl font-serif italic line-clamp-3">
            {summary}
          </p>

          <footer className="flex items-center gap-4 mt-2 text-zinc-500 text-xs uppercase font-bold tracking-wider">
            <span>Por {author}</span>
            <span className="h-1 w-1 rounded-full bg-zinc-700" />
            <span>{date}</span>
          </footer>
        </div>
      </Link>
    </article>
  );
}
