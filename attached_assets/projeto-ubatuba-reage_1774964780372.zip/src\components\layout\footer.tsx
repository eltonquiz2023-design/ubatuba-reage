import React from "react";
import Link from "next/link";
import { InterceptLogo, ChevronRight } from "@/components/icons";
import {
  WhatsAppIcon,
  BlueSkyIcon,
  XIcon,
  InstagramIcon,
  ThreadsIcon,
  FacebookIcon,
  YouTubeIcon,
  TikTokIcon,
} from "@/components/icons";

const navLinks = [
  { label: "Matérias",       href: "/" },
  { label: "Vozes",          href: "/vozes" },
  { label: "Vídeos",         href: "/videos" },
  { label: "Newsletter",     href: "/newsletter" },
  { label: "Seja Nossa Fonte", href: "/fonte" },
];

const legalLinks = [
  { label: "Quem Somos",             href: "/quem-somos" },
  { label: "Perguntas frequentes",   href: "/faq" },
  { label: "Política de privacidade", href: "/privacidade" },
  { label: "Termos de Uso",          href: "/termos" },
];

const socials = [
  { icon: WhatsAppIcon,  href: "https://whatsapp.com/channel/0029VaAB1FrDDmFBjRr0Bm1I", label: "WhatsApp" },
  { icon: BlueSkyIcon,   href: "https://bsky.app/profile/theintercept.com.br",           label: "Bluesky" },
  { icon: XIcon,         href: "https://twitter.com/intercept_br",                        label: "X" },
  { icon: InstagramIcon, href: "https://instagram.com/interceptbrasil",                    label: "Instagram" },
  { icon: ThreadsIcon,   href: "https://threads.net/@interceptbrasil",                     label: "Threads" },
  { icon: FacebookIcon,  href: "https://facebook.com/TheInterceptBrasil",                  label: "Facebook" },
  { icon: YouTubeIcon,   href: "https://youtube.com/c/InterceptBrasil",                    label: "YouTube" },
  { icon: TikTokIcon,    href: "https://tiktok.com/@interceptbrasil",                      label: "TikTok" },
];

export function Footer() {
  return (
    <footer className="bg-[#e8e8e8]">
      {/* Top row: logo + CTA + socials */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 px-8 md:px-10 py-8 border-b border-black/10">
        {/* Logo */}
        <Link href="/" className="flex-shrink-0">
          <InterceptLogo className="w-[180px] h-auto" fill="black" />
        </Link>

        {/* CTA Button */}
        <Link
          href="/apoie"
          className="flex items-center gap-2 bg-[#4B59F7] text-white hover:bg-[#3d4ad4] transition-colors px-6 py-3 text-xs font-black uppercase tracking-[0.15em] font-mono"
        >
          Apoie o Intercept Hoje
          <ChevronRight className="w-4 h-4" />
        </Link>

        {/* Social icons */}
        <div className="flex items-center gap-1 flex-wrap">
          {socials.map(({ icon: Icon, href, label }) => (
            <Link
              key={label}
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={label}
              className="w-9 h-9 flex items-center justify-center text-black/50 hover:text-black transition-colors"
            >
              <Icon className="w-[18px] h-[18px]" />
            </Link>
          ))}
        </div>
      </div>

      {/* Nav section links: Boxed on mobile, horizontal on desktop */}
      <div className="flex flex-col md:flex-row md:flex-wrap gap-0 md:gap-x-8 md:gap-y-4 px-0 md:px-10 py-0 md:py-8 border-b border-black/10">
        {navLinks.map(({ label, href }) => (
          <Link
            key={label}
            href={href}
            className="flex items-center justify-between px-8 py-6 border-b md:border-none border-black/10 md:p-0 md:flex-col md:items-start gap-1 group w-full md:w-auto"
          >
            {/* Desktop-only thick top bar */}
            <span className="hidden md:block w-full h-[3px] bg-black group-hover:bg-[#4B59F7] transition-colors" />
            
            <span className="text-black text-sm font-black uppercase tracking-[0.1em] group-hover:text-[#4B59F7] transition-colors">
              {label}
            </span>

            {/* Mobile-only chevron */}
            <ChevronRight className="w-5 h-5 text-black/30 md:hidden" />
          </Link>
        ))}
      </div>

      {/* Bottom legal row */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 px-8 md:px-10 py-5">
        <p className="text-black/50 text-xs font-mono">
          ©{new Date().getFullYear()} Intercept Brasil. Todos os direitos reservados.
        </p>
        <div className="flex flex-wrap gap-x-4 gap-y-1">
          {legalLinks.map(({ label, href }) => (
            <Link
              key={label}
              href={href}
              className="text-black/50 hover:text-black text-xs font-mono transition-colors"
            >
              {label}
            </Link>
          ))}
        </div>
      </div>
    </footer>
  );
}
