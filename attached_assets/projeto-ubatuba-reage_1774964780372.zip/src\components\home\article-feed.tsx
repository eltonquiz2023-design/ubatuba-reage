"use client";

import React from "react";
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";

/* ─── Article row: image | title+meta | lead ─── */
interface ArticleRowProps {
  slug: string;
  category: string;
  title: string;
  lead: string;
  date: string;
  author: string;
  imageUrl: string;
}

export function ArticleRow({
  slug,
  category,
  title,
  lead,
  date,
  author,
  imageUrl,
}: ArticleRowProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, ease: "easeOut" }}
    >
      <Link
        href={`/article/${slug}`}
        className="group flex flex-col lg:flex-row items-stretch gap-0 bg-white hover:bg-gray-50 border-b border-black/10 transition-colors"
      >
        {/* Thumbnail — full width on mobile, fixed width on desktop */}
        <div className="relative flex-shrink-0 w-full lg:w-[337px] aspect-video lg:h-[190px] overflow-hidden bg-gray-200">
          <Image
            src={imageUrl}
            alt={title}
            fill
            sizes="(max-width: 1024px) 100vw, 337px"
            className="object-cover group-hover:scale-[1.02] transition-transform duration-500 ease-out"
          />
        </div>

        {/* Middle: title + meta */}
        <div className="flex flex-col justify-center gap-2 px-4 py-4 lg:py-4 flex-1 min-w-0 lg:border-r border-black/10">
          <h3 className="text-black text-[21px] md:text-[26px] font-bold leading-[1.1] tracking-tight group-hover:underline decoration-1 underline-offset-4">
            {title}
          </h3>
          <div className="flex items-center gap-2 text-gray-400 text-[10px] font-mono uppercase tracking-widest mt-2">
            <span>{date}</span>
            {author && (
              <>
                <span className="text-gray-300">—</span>
                <span className="text-[#4B59F7] font-black">{author}</span>
              </>
            )}
          </div>
        </div>

        {/* Right: lead text (Desktop only) */}
        <div className="hidden lg:flex flex-col justify-center px-6 py-4 w-[260px] flex-shrink-0">
          <p className="text-gray-500 text-sm font-serif italic leading-relaxed line-clamp-4">
            {lead}
          </p>
        </div>
      </Link>
    </motion.div>
  );
}

/* ─── Load more button ─── */
export function LoadMoreButton({ href = "/" }: { href?: string }) {
  return (
    <div className="flex justify-center py-8 bg-[#f0f0f0]">
      <Link
        href={href}
        className="border border-black text-black hover:bg-black hover:text-white transition-colors px-10 py-3 text-xs font-black uppercase tracking-[0.2em] font-mono flex items-center gap-2"
      >
        Acesse Mais Matérias
        <span className="text-base leading-none">›</span>
      </Link>
    </div>
  );
}
